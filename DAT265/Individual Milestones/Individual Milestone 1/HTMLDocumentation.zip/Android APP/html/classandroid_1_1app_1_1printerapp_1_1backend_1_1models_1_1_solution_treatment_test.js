var classandroid_1_1app_1_1printerapp_1_1backend_1_1models_1_1_solution_treatment_test =
[
    [ "getComment", "classandroid_1_1app_1_1printerapp_1_1backend_1_1models_1_1_solution_treatment_test.html#a2ffa44a63fe0ce039efce1e82d925689", null ],
    [ "getName", "classandroid_1_1app_1_1printerapp_1_1backend_1_1models_1_1_solution_treatment_test.html#a6821d1a72e1e5f3f362748e9ef73135f", null ],
    [ "getPartTestId", "classandroid_1_1app_1_1printerapp_1_1backend_1_1models_1_1_solution_treatment_test.html#a6cc045eda250f40624e2b161f7f6795f", null ],
    [ "getTemperature", "classandroid_1_1app_1_1printerapp_1_1backend_1_1models_1_1_solution_treatment_test.html#a62de3c63ff63999622d7a5de224ec7c1", null ],
    [ "getTimeEvent", "classandroid_1_1app_1_1printerapp_1_1backend_1_1models_1_1_solution_treatment_test.html#aae10c712f01a2f5143adfdaca9d275c5", null ],
    [ "getType", "classandroid_1_1app_1_1printerapp_1_1backend_1_1models_1_1_solution_treatment_test.html#ad685aa0868e05c9ecd5564bf60b7c80f", null ],
    [ "setComment", "classandroid_1_1app_1_1printerapp_1_1backend_1_1models_1_1_solution_treatment_test.html#a01378ab9003236f0706a180fd97370aa", null ],
    [ "setName", "classandroid_1_1app_1_1printerapp_1_1backend_1_1models_1_1_solution_treatment_test.html#a54eafc90448b7f99c371ea749ae19cfb", null ],
    [ "setPartTestId", "classandroid_1_1app_1_1printerapp_1_1backend_1_1models_1_1_solution_treatment_test.html#ab181a22241a9d5add2ff93456b2cceb9", null ],
    [ "setTemperature", "classandroid_1_1app_1_1printerapp_1_1backend_1_1models_1_1_solution_treatment_test.html#af638d89550e83360998aca2aa0a71c63", null ],
    [ "setTimeEvent", "classandroid_1_1app_1_1printerapp_1_1backend_1_1models_1_1_solution_treatment_test.html#ac4fbc57779b81bed5df28d20a21bb357", null ],
    [ "setType", "classandroid_1_1app_1_1printerapp_1_1backend_1_1models_1_1_solution_treatment_test.html#a60f8e6a5bdcac2b009f15250758e0185", null ]
];