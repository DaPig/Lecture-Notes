var dir_0efcdae641688565ce326aa3d4f6bef6 =
[
    [ "buildDataController.java", "build_data_controller_8java.html", [
      [ "buildDataController", "classandroid_1_1app_1_1printerapp_1_1displaying_data_1_1_c_m_build_data_1_1build_data_controller.html", "classandroid_1_1app_1_1printerapp_1_1displaying_data_1_1_c_m_build_data_1_1build_data_controller" ]
    ] ],
    [ "buildDataModel.java", "build_data_model_8java.html", [
      [ "buildDataModel", "classandroid_1_1app_1_1printerapp_1_1displaying_data_1_1_c_m_build_data_1_1build_data_model.html", "classandroid_1_1app_1_1printerapp_1_1displaying_data_1_1_c_m_build_data_1_1build_data_model" ]
    ] ]
];