var enumandroid_1_1app_1_1printerapp_1_1util_1_1ui_1_1enums_1_1qr_code_type =
[
    [ "qrCodeType", "enumandroid_1_1app_1_1printerapp_1_1util_1_1ui_1_1enums_1_1qr_code_type.html#a16a30694d4e0a9407bb1cca5856ff0e4", null ],
    [ "getValue", "enumandroid_1_1app_1_1printerapp_1_1util_1_1ui_1_1enums_1_1qr_code_type.html#acabf20d34e39fd4c3098762adca1ade6", null ],
    [ "Build", "enumandroid_1_1app_1_1printerapp_1_1util_1_1ui_1_1enums_1_1qr_code_type.html#a255c737201ab653d523a375ee0d6bfe0", null ],
    [ "Material", "enumandroid_1_1app_1_1printerapp_1_1util_1_1ui_1_1enums_1_1qr_code_type.html#a0f58e6feb874393be3d9a497198a5f2a", null ],
    [ "Part", "enumandroid_1_1app_1_1printerapp_1_1util_1_1ui_1_1enums_1_1qr_code_type.html#a92d7d9a4d62e20ac65dbef2bd187d306", null ]
];