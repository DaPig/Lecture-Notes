var classandroid_1_1app_1_1printerapp_1_1backend_1_1models_1_1_update_aging_treatment_test =
[
    [ "getComment", "classandroid_1_1app_1_1printerapp_1_1backend_1_1models_1_1_update_aging_treatment_test.html#afa9b6084209449fcc8b5f6a93034834b", null ],
    [ "getName", "classandroid_1_1app_1_1printerapp_1_1backend_1_1models_1_1_update_aging_treatment_test.html#ac61e7d1f8d32532747c376bcb9fad184", null ],
    [ "getPartTestId", "classandroid_1_1app_1_1printerapp_1_1backend_1_1models_1_1_update_aging_treatment_test.html#a513429f6357367528a108a8adc17c5e2", null ],
    [ "getTemperature", "classandroid_1_1app_1_1printerapp_1_1backend_1_1models_1_1_update_aging_treatment_test.html#a8569a377193eb650bc1acef860da3398", null ],
    [ "getTimeEvent", "classandroid_1_1app_1_1printerapp_1_1backend_1_1models_1_1_update_aging_treatment_test.html#add2b3c60ef11a06d90eabd8269c18817", null ],
    [ "getType", "classandroid_1_1app_1_1printerapp_1_1backend_1_1models_1_1_update_aging_treatment_test.html#a47c075caa1c22798e8c504b920912b87", null ],
    [ "setComment", "classandroid_1_1app_1_1printerapp_1_1backend_1_1models_1_1_update_aging_treatment_test.html#a8e92a526eac24b377754cbe7b3ceedec", null ],
    [ "setName", "classandroid_1_1app_1_1printerapp_1_1backend_1_1models_1_1_update_aging_treatment_test.html#a845b33c715607ed76b3737bdda6fa1a0", null ],
    [ "setPartTestId", "classandroid_1_1app_1_1printerapp_1_1backend_1_1models_1_1_update_aging_treatment_test.html#a337dc462f1250d6e6e5c287c8bb2371d", null ],
    [ "setTemperature", "classandroid_1_1app_1_1printerapp_1_1backend_1_1models_1_1_update_aging_treatment_test.html#a3aecf69363fe588ebba4f8c17de9e8b9", null ],
    [ "setTimeEvent", "classandroid_1_1app_1_1printerapp_1_1backend_1_1models_1_1_update_aging_treatment_test.html#add0539680bbe85cbd27998454d36fc36", null ],
    [ "setType", "classandroid_1_1app_1_1printerapp_1_1backend_1_1models_1_1_update_aging_treatment_test.html#a9c3569fd5cf2a51cf350635965787379", null ]
];