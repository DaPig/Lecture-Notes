var classandroid_1_1app_1_1printerapp_1_1backend_1_1models_1_1_number_of_tests =
[
    [ "getAgingTests", "classandroid_1_1app_1_1printerapp_1_1backend_1_1models_1_1_number_of_tests.html#a546792c481a3dcbeac2602f48d54fdc0", null ],
    [ "getGeneralTests", "classandroid_1_1app_1_1printerapp_1_1backend_1_1models_1_1_number_of_tests.html#ae974b03baa4cd8aa61e801f46b103009", null ],
    [ "getHardeningTests", "classandroid_1_1app_1_1printerapp_1_1backend_1_1models_1_1_number_of_tests.html#a07cf5f28bedd1c97ae91ac5b10ba5e49", null ],
    [ "getSolutionTreatmenTest", "classandroid_1_1app_1_1printerapp_1_1backend_1_1models_1_1_number_of_tests.html#a585aecf0d7d685eca9c7890c161bbf27", null ],
    [ "getStressRelievingTests", "classandroid_1_1app_1_1printerapp_1_1backend_1_1models_1_1_number_of_tests.html#aec2d6d273dc2d7989e5e2a2e307074d5", null ],
    [ "getTamperingTests", "classandroid_1_1app_1_1printerapp_1_1backend_1_1models_1_1_number_of_tests.html#a6708d3d5640043a57da67e7553643d0d", null ],
    [ "setAgingTests", "classandroid_1_1app_1_1printerapp_1_1backend_1_1models_1_1_number_of_tests.html#a202a37d40b17bf9a1584cca52f36f6fe", null ],
    [ "setGeneralTests", "classandroid_1_1app_1_1printerapp_1_1backend_1_1models_1_1_number_of_tests.html#ad0c94401623e2486ebcfa388b578c901", null ],
    [ "setHardeningTests", "classandroid_1_1app_1_1printerapp_1_1backend_1_1models_1_1_number_of_tests.html#a486aad8492e343cf9b306029106225b1", null ],
    [ "setSolutionTreatmenTest", "classandroid_1_1app_1_1printerapp_1_1backend_1_1models_1_1_number_of_tests.html#a5f9d5049bed92cb68ff7da880d3a0d4e", null ],
    [ "setStressRelievingTests", "classandroid_1_1app_1_1printerapp_1_1backend_1_1models_1_1_number_of_tests.html#ad67a2cec77a1e320343f5e678657d65b", null ],
    [ "setTamperingTests", "classandroid_1_1app_1_1printerapp_1_1backend_1_1models_1_1_number_of_tests.html#a3a91fd3478bc86b96ef27fc687d9eff7", null ]
];