var classandroid_1_1app_1_1printerapp_1_1login_screen_1_1login_screen_activity =
[
    [ "onClick", "classandroid_1_1app_1_1printerapp_1_1login_screen_1_1login_screen_activity.html#a541afd51c62847edb10023fb5e241850", null ],
    [ "onCreate", "classandroid_1_1app_1_1printerapp_1_1login_screen_1_1login_screen_activity.html#a6312c897b57eff68ad408c2242fe8723", null ],
    [ "sendMessageToUser", "classandroid_1_1app_1_1printerapp_1_1login_screen_1_1login_screen_activity.html#a9e8dea47ced550c49d0afef29b5061dc", null ]
];