var classandroid_1_1app_1_1printerapp_1_1home_screen_1_1text_scanner_1_1text_scanner_fragment =
[
    [ "textScannerFragment", "classandroid_1_1app_1_1printerapp_1_1home_screen_1_1text_scanner_1_1text_scanner_fragment.html#a3707e4729a09d5a5e62a501df1e49956", null ],
    [ "onCreateView", "classandroid_1_1app_1_1printerapp_1_1home_screen_1_1text_scanner_1_1text_scanner_fragment.html#a8591a64ce974ced74983c44970103298", null ],
    [ "searchButtonClicked", "classandroid_1_1app_1_1printerapp_1_1home_screen_1_1text_scanner_1_1text_scanner_fragment.html#a3e5dd309aa11db3d7c392b7921aa1271", null ],
    [ "sendMessageToUser", "classandroid_1_1app_1_1printerapp_1_1home_screen_1_1text_scanner_1_1text_scanner_fragment.html#afb1edf1388f66c0aed5c6fc3c75e46f2", null ],
    [ "startProgressDialog", "classandroid_1_1app_1_1printerapp_1_1home_screen_1_1text_scanner_1_1text_scanner_fragment.html#a3ebc47cc930013c3314545737c39cfef", null ],
    [ "stopProgressDialog", "classandroid_1_1app_1_1printerapp_1_1home_screen_1_1text_scanner_1_1text_scanner_fragment.html#a7bc279bbaecf1484af923aae5dbd61da", null ]
];