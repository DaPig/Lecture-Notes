var dir_cc65261fedee3094757e16b440d4cf3c =
[
    [ "tokenInterfaces.java", "token_interfaces_8java.html", [
      [ "tokenInterfaces", "interfaceandroid_1_1app_1_1printerapp_1_1backend_1_1token_management_1_1token_interfaces.html", "interfaceandroid_1_1app_1_1printerapp_1_1backend_1_1token_management_1_1token_interfaces" ]
    ] ],
    [ "TokenManager.java", "_token_manager_8java.html", [
      [ "TokenManager", "classandroid_1_1app_1_1printerapp_1_1backend_1_1token_management_1_1_token_manager.html", "classandroid_1_1app_1_1printerapp_1_1backend_1_1token_management_1_1_token_manager" ]
    ] ]
];