var dir_a71f8321bce564b5956cb64e3ad1472f =
[
    [ "appcompat", "dir_5fcaefcd152570e6141c2e61733134dc.html", "dir_5fcaefcd152570e6141c2e61733134dc" ],
    [ "cardview", "dir_7e97edb3d2eee09d447ca4f9150d93ec.html", "dir_7e97edb3d2eee09d447ca4f9150d93ec" ],
    [ "recyclerview", "dir_78429fedf25ac3cba628d6711a4aabff.html", "dir_78429fedf25ac3cba628d6711a4aabff" ]
];