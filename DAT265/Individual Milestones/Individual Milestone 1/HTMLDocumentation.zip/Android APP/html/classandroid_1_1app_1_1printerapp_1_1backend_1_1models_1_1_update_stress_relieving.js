var classandroid_1_1app_1_1printerapp_1_1backend_1_1models_1_1_update_stress_relieving =
[
    [ "getComment", "classandroid_1_1app_1_1printerapp_1_1backend_1_1models_1_1_update_stress_relieving.html#a4422991cae1a269933af50e79944a4b3", null ],
    [ "getName", "classandroid_1_1app_1_1printerapp_1_1backend_1_1models_1_1_update_stress_relieving.html#a5744a02c01c3c0233189ed844b574647", null ],
    [ "getPartTestId", "classandroid_1_1app_1_1printerapp_1_1backend_1_1models_1_1_update_stress_relieving.html#a5b0f5d4c5058840934ebb02c8abc2ff9", null ],
    [ "getShieldingGas", "classandroid_1_1app_1_1printerapp_1_1backend_1_1models_1_1_update_stress_relieving.html#ae775d959dae78a9bc8d091f396dda395", null ],
    [ "getTemperature", "classandroid_1_1app_1_1printerapp_1_1backend_1_1models_1_1_update_stress_relieving.html#aa2b780ed2ecd37b41a3ef5e60af08fd2", null ],
    [ "getTimeEvent", "classandroid_1_1app_1_1printerapp_1_1backend_1_1models_1_1_update_stress_relieving.html#a977a0049b72de84b31fd64ac5c74d7b8", null ],
    [ "getType", "classandroid_1_1app_1_1printerapp_1_1backend_1_1models_1_1_update_stress_relieving.html#a3eb85e94642bfdcfd1a6f9a113430bc9", null ],
    [ "setComment", "classandroid_1_1app_1_1printerapp_1_1backend_1_1models_1_1_update_stress_relieving.html#a70340d2bf8199ee5c9615a66f8cca160", null ],
    [ "setName", "classandroid_1_1app_1_1printerapp_1_1backend_1_1models_1_1_update_stress_relieving.html#a12e3726d6b511df971c461a5f7617bf7", null ],
    [ "setPartTestId", "classandroid_1_1app_1_1printerapp_1_1backend_1_1models_1_1_update_stress_relieving.html#a9ae9049fca935f710faf8d89e4d4ffb6", null ],
    [ "setShieldingGas", "classandroid_1_1app_1_1printerapp_1_1backend_1_1models_1_1_update_stress_relieving.html#abc6f1d22f360eccbc11c5637f888839a", null ],
    [ "setTemperature", "classandroid_1_1app_1_1printerapp_1_1backend_1_1models_1_1_update_stress_relieving.html#adccc7634e6e4d58198a2a8bef71b2a21", null ],
    [ "setTimeEvent", "classandroid_1_1app_1_1printerapp_1_1backend_1_1models_1_1_update_stress_relieving.html#a0debf6f9d2e714735347464048552135", null ],
    [ "setType", "classandroid_1_1app_1_1printerapp_1_1backend_1_1models_1_1_update_stress_relieving.html#a83f79d6e9d210e78796605b7de711b8b", null ]
];