var classandroid_1_1app_1_1printerapp_1_1backend_1_1models_1_1_user =
[
    [ "getFirstname", "classandroid_1_1app_1_1printerapp_1_1backend_1_1models_1_1_user.html#abc9d05e9e9e34274f0343ba87dd5772a", null ],
    [ "getId", "classandroid_1_1app_1_1printerapp_1_1backend_1_1models_1_1_user.html#a1dd0827ffc28b471d1b0024dd209ba73", null ],
    [ "getLastname", "classandroid_1_1app_1_1printerapp_1_1backend_1_1models_1_1_user.html#a627d4419e31f6c839b0d46db843f253f", null ],
    [ "getRoles", "classandroid_1_1app_1_1printerapp_1_1backend_1_1models_1_1_user.html#ac541806e791596cfbd02de9384c28c16", null ],
    [ "getUsername", "classandroid_1_1app_1_1printerapp_1_1backend_1_1models_1_1_user.html#a54f45c4d20e8c0d63bbc91587d06773a", null ],
    [ "setFirstname", "classandroid_1_1app_1_1printerapp_1_1backend_1_1models_1_1_user.html#ae19f73ea78ee1fddf90424f7b47e09a7", null ],
    [ "setId", "classandroid_1_1app_1_1printerapp_1_1backend_1_1models_1_1_user.html#a745755cd198b91d02a33b50be34c8c0f", null ],
    [ "setLastname", "classandroid_1_1app_1_1printerapp_1_1backend_1_1models_1_1_user.html#a3e332c8cab56fc7294bb9a488f461eed", null ],
    [ "setRoles", "classandroid_1_1app_1_1printerapp_1_1backend_1_1models_1_1_user.html#a15bb61b7b9fbdd9a213b0160043496a9", null ],
    [ "setUsername", "classandroid_1_1app_1_1printerapp_1_1backend_1_1models_1_1_user.html#a5652389b93a11f21b4fb0e6bf168ae44", null ]
];