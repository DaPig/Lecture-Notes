var classandroid_1_1app_1_1printerapp_1_1util_1_1ui_1_1_my_application =
[
    [ "getPartTestId", "classandroid_1_1app_1_1printerapp_1_1util_1_1ui_1_1_my_application.html#a0ebf723e228534ac08e8b2304281d8c9", null ],
    [ "getQrcode", "classandroid_1_1app_1_1printerapp_1_1util_1_1ui_1_1_my_application.html#aa8f783c53fad0e10ca78d2c89a8d1d7b", null ],
    [ "getRole", "classandroid_1_1app_1_1printerapp_1_1util_1_1ui_1_1_my_application.html#a596a34094b188ad275fb17d6e6a73f85", null ],
    [ "getToken", "classandroid_1_1app_1_1printerapp_1_1util_1_1ui_1_1_my_application.html#aec1353ed621c1253a46744f523245051", null ],
    [ "setPartTestId", "classandroid_1_1app_1_1printerapp_1_1util_1_1ui_1_1_my_application.html#a144a05096a687afebfac86d3fa56b6ce", null ],
    [ "setQrcode", "classandroid_1_1app_1_1printerapp_1_1util_1_1ui_1_1_my_application.html#a2e771fe849780d6a9923fb79e0173c61", null ],
    [ "setRole", "classandroid_1_1app_1_1printerapp_1_1util_1_1ui_1_1_my_application.html#a822430807f5b90b214f9cb7360f4108a", null ],
    [ "setToken", "classandroid_1_1app_1_1printerapp_1_1util_1_1ui_1_1_my_application.html#a07b8c788827101b3f0946dfe9dd3843d", null ]
];