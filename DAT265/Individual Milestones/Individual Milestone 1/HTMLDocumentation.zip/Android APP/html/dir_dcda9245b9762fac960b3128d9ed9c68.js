var dir_dcda9245b9762fac960b3128d9ed9c68 =
[
    [ "box.java", "box_8java.html", [
      [ "box", "classandroid_1_1app_1_1printerapp_1_1home_screen_1_1_q_r_scanner_1_1box.html", "classandroid_1_1app_1_1printerapp_1_1home_screen_1_1_q_r_scanner_1_1box" ]
    ] ],
    [ "QRreaderController.java", "_q_rreader_controller_8java.html", [
      [ "QRreaderController", "classandroid_1_1app_1_1printerapp_1_1home_screen_1_1_q_r_scanner_1_1_q_rreader_controller.html", "classandroid_1_1app_1_1printerapp_1_1home_screen_1_1_q_r_scanner_1_1_q_rreader_controller" ]
    ] ],
    [ "QRreaderFragment.java", "_q_rreader_fragment_8java.html", [
      [ "QRreaderFragment", "classandroid_1_1app_1_1printerapp_1_1home_screen_1_1_q_r_scanner_1_1_q_rreader_fragment.html", "classandroid_1_1app_1_1printerapp_1_1home_screen_1_1_q_r_scanner_1_1_q_rreader_fragment" ]
    ] ],
    [ "QRreaderInterface.java", "_q_rreader_interface_8java.html", [
      [ "QRreaderInterface", "interfaceandroid_1_1app_1_1printerapp_1_1home_screen_1_1_q_r_scanner_1_1_q_rreader_interface.html", [
        [ "rControllerToViewInterface", "interfaceandroid_1_1app_1_1printerapp_1_1home_screen_1_1_q_r_scanner_1_1_q_rreader_interface_1_1r_controller_to_view_interface.html", "interfaceandroid_1_1app_1_1printerapp_1_1home_screen_1_1_q_r_scanner_1_1_q_rreader_interface_1_1r_controller_to_view_interface" ],
        [ "rViewInterface", "interfaceandroid_1_1app_1_1printerapp_1_1home_screen_1_1_q_r_scanner_1_1_q_rreader_interface_1_1r_view_interface.html", "interfaceandroid_1_1app_1_1printerapp_1_1home_screen_1_1_q_r_scanner_1_1_q_rreader_interface_1_1r_view_interface" ]
      ] ],
      [ "rViewInterface", "interfaceandroid_1_1app_1_1printerapp_1_1home_screen_1_1_q_r_scanner_1_1_q_rreader_interface_1_1r_view_interface.html", "interfaceandroid_1_1app_1_1printerapp_1_1home_screen_1_1_q_r_scanner_1_1_q_rreader_interface_1_1r_view_interface" ],
      [ "rControllerToViewInterface", "interfaceandroid_1_1app_1_1printerapp_1_1home_screen_1_1_q_r_scanner_1_1_q_rreader_interface_1_1r_controller_to_view_interface.html", "interfaceandroid_1_1app_1_1printerapp_1_1home_screen_1_1_q_r_scanner_1_1_q_rreader_interface_1_1r_controller_to_view_interface" ]
    ] ]
];