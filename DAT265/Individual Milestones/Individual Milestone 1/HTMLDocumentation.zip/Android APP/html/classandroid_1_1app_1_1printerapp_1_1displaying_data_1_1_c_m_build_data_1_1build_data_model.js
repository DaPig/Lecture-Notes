var classandroid_1_1app_1_1printerapp_1_1displaying_data_1_1_c_m_build_data_1_1build_data_model =
[
    [ "buildDataModel", "classandroid_1_1app_1_1printerapp_1_1displaying_data_1_1_c_m_build_data_1_1build_data_model.html#a3220849262f6d6194a1a8a17e678d27b", null ],
    [ "getMapWithData", "classandroid_1_1app_1_1printerapp_1_1displaying_data_1_1_c_m_build_data_1_1build_data_model.html#af84f0c20841c90476ca233bbd890ba5f", null ],
    [ "itemClicked", "classandroid_1_1app_1_1printerapp_1_1displaying_data_1_1_c_m_build_data_1_1build_data_model.html#a00a80f16145c9d9b2a045b5fca26a146", null ],
    [ "updateDatabaseContent", "classandroid_1_1app_1_1printerapp_1_1displaying_data_1_1_c_m_build_data_1_1build_data_model.html#ad1ee0c38fb28606074416d4fe0025a8e", null ]
];