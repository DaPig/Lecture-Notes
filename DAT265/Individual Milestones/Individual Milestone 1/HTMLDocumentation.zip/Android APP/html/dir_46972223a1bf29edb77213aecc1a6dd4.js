var dir_46972223a1bf29edb77213aecc1a6dd4 =
[
    [ "BuildConfig.java", "app_2build_2generated_2source_2build_config_2debug_2android_2app_2printerapp_2_build_config_8java.html", [
      [ "BuildConfig", "classandroid_1_1app_1_1printerapp_1_1_build_config.html", null ]
    ] ]
];