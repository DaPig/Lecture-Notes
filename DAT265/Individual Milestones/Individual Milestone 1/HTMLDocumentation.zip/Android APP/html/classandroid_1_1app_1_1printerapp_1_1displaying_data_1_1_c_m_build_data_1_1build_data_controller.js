var classandroid_1_1app_1_1printerapp_1_1displaying_data_1_1_c_m_build_data_1_1build_data_controller =
[
    [ "buildDataController", "classandroid_1_1app_1_1printerapp_1_1displaying_data_1_1_c_m_build_data_1_1build_data_controller.html#a8b14f639b5f8834cde820333a84cf469", null ],
    [ "changeContent", "classandroid_1_1app_1_1printerapp_1_1displaying_data_1_1_c_m_build_data_1_1build_data_controller.html#ae93e0422438b64b2b91dd1a8af5ceff7", null ],
    [ "didEnterDate", "classandroid_1_1app_1_1printerapp_1_1displaying_data_1_1_c_m_build_data_1_1build_data_controller.html#ac94519b364ec194987493af7ff3bdc27", null ],
    [ "didEnterStringData", "classandroid_1_1app_1_1printerapp_1_1displaying_data_1_1_c_m_build_data_1_1build_data_controller.html#af3367cbffe0ddb61f83bbf69f269ed0f", null ],
    [ "didEnterTime", "classandroid_1_1app_1_1printerapp_1_1displaying_data_1_1_c_m_build_data_1_1build_data_controller.html#a1a264e3172040da3295691c8903f3699", null ],
    [ "didSelectAPowerCondition", "classandroid_1_1app_1_1printerapp_1_1displaying_data_1_1_c_m_build_data_1_1build_data_controller.html#a202539b524ca13b4f88fc0956f8765e5", null ],
    [ "displayPersonality", "classandroid_1_1app_1_1printerapp_1_1displaying_data_1_1_c_m_build_data_1_1build_data_controller.html#a588210155962ee7704a870e85895720d", null ],
    [ "getMapWithData", "classandroid_1_1app_1_1printerapp_1_1displaying_data_1_1_c_m_build_data_1_1build_data_controller.html#a776d8420c29d7b52b4abd1c0a2c7b0db", null ],
    [ "itemClicked", "classandroid_1_1app_1_1printerapp_1_1displaying_data_1_1_c_m_build_data_1_1build_data_controller.html#ab14dc5f91b7b97600cf3c25e7e759800", null ],
    [ "sendMessageToUser", "classandroid_1_1app_1_1printerapp_1_1displaying_data_1_1_c_m_build_data_1_1build_data_controller.html#a979b242ff927168261ca1a50794bcbe0", null ]
];