var dir_079a9fd183069656652cfdac63dcd229 =
[
    [ "dialogPowderConditionAdapter.java", "dialog_powder_condition_adapter_8java.html", [
      [ "dialogPowderConditionAdapter", "classandroid_1_1app_1_1printerapp_1_1adapters_1_1dialog_powder_condition_adapter.html", "classandroid_1_1app_1_1printerapp_1_1adapters_1_1dialog_powder_condition_adapter" ]
    ] ],
    [ "gridViewAdapter.java", "grid_view_adapter_8java.html", [
      [ "gridViewAdapter", "classandroid_1_1app_1_1printerapp_1_1adapters_1_1grid_view_adapter.html", "classandroid_1_1app_1_1printerapp_1_1adapters_1_1grid_view_adapter" ]
    ] ],
    [ "viewPagerAdapter.java", "view_pager_adapter_8java.html", [
      [ "viewPagerAdapter", "classandroid_1_1app_1_1printerapp_1_1adapters_1_1view_pager_adapter.html", "classandroid_1_1app_1_1printerapp_1_1adapters_1_1view_pager_adapter" ]
    ] ]
];