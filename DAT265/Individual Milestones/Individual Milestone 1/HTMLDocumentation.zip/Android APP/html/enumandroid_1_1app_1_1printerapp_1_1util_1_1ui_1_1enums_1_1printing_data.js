var enumandroid_1_1app_1_1printerapp_1_1util_1_1ui_1_1enums_1_1printing_data =
[
    [ "printingData", "enumandroid_1_1app_1_1printerapp_1_1util_1_1ui_1_1enums_1_1printing_data.html#a0c827e997a788706d9b058dea4ce8a56", null ],
    [ "getValue", "enumandroid_1_1app_1_1printerapp_1_1util_1_1ui_1_1enums_1_1printing_data.html#a018387dda5adf4dd7f4fb754be6f984f", null ],
    [ "buildID", "enumandroid_1_1app_1_1printerapp_1_1util_1_1ui_1_1enums_1_1printing_data.html#abffbd67d84ceef95b6c54f5714bd4d35", null ],
    [ "comments", "enumandroid_1_1app_1_1printerapp_1_1util_1_1ui_1_1enums_1_1printing_data.html#a6213efd2bbc988d5e9616b5509f1e374", null ],
    [ "dpcFactor", "enumandroid_1_1app_1_1printerapp_1_1util_1_1ui_1_1enums_1_1printing_data.html#a253e9239fb73d0b0690d41030eb0766c", null ],
    [ "endTime", "enumandroid_1_1app_1_1printerapp_1_1util_1_1ui_1_1enums_1_1printing_data.html#ad1dbf2d074e3d5bc8f45f7470a9db466", null ],
    [ "minExposureTime", "enumandroid_1_1app_1_1printerapp_1_1util_1_1ui_1_1enums_1_1printing_data.html#a8014e0d20b5e0363f6554e5bd6896245", null ],
    [ "numberLayers", "enumandroid_1_1app_1_1printerapp_1_1util_1_1ui_1_1enums_1_1printing_data.html#a8d08e70ce92d030942ad39e1f3ec20f2", null ],
    [ "operator", "enumandroid_1_1app_1_1printerapp_1_1util_1_1ui_1_1enums_1_1printing_data.html#acc50f2b3706055fe096365a551fd7ea6", null ],
    [ "platformMaterial", "enumandroid_1_1app_1_1printerapp_1_1util_1_1ui_1_1enums_1_1printing_data.html#a08f4b1d4415c5a408dc1516c154cef5f", null ],
    [ "platformWeight", "enumandroid_1_1app_1_1printerapp_1_1util_1_1ui_1_1enums_1_1printing_data.html#a47f939c99e7ad2a2218c5de76ce4897d", null ],
    [ "powderCondition", "enumandroid_1_1app_1_1printerapp_1_1util_1_1ui_1_1enums_1_1printing_data.html#a3d276d4b85f36c620d05d09332ece65e", null ],
    [ "powderweightEnd", "enumandroid_1_1app_1_1printerapp_1_1util_1_1ui_1_1enums_1_1printing_data.html#ad53d77f7b729927f48fe162a27a2b6e7", null ],
    [ "powderWeightStart", "enumandroid_1_1app_1_1printerapp_1_1util_1_1ui_1_1enums_1_1printing_data.html#aa9af6ac9c477cfad136b3140072431bd", null ],
    [ "powerUsed", "enumandroid_1_1app_1_1printerapp_1_1util_1_1ui_1_1enums_1_1printing_data.html#aefc0d317e4a88306bf6cd93d0a01e2a4", null ],
    [ "printedTime", "enumandroid_1_1app_1_1printerapp_1_1util_1_1ui_1_1enums_1_1printing_data.html#ac8d590b4c9b375593c4776896ee15d35", null ],
    [ "printingDate", "enumandroid_1_1app_1_1printerapp_1_1util_1_1ui_1_1enums_1_1printing_data.html#a4f98b9cbbd1e59e6acacbeef47da85eb", null ],
    [ "startTime", "enumandroid_1_1app_1_1printerapp_1_1util_1_1ui_1_1enums_1_1printing_data.html#a5d60e36b4d808c5d961e19d860cbe7b0", null ],
    [ "typeOfmachine", "enumandroid_1_1app_1_1printerapp_1_1util_1_1ui_1_1enums_1_1printing_data.html#a56f92b46cea2b4978a793567d9ffac66", null ],
    [ "weightPowderWaste", "enumandroid_1_1app_1_1printerapp_1_1util_1_1ui_1_1enums_1_1printing_data.html#ae2745504beb9e5b8ffc67b902edf135a", null ]
];