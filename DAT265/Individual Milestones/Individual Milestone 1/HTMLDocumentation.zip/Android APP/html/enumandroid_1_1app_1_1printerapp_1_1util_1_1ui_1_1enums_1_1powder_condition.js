var enumandroid_1_1app_1_1printerapp_1_1util_1_1ui_1_1enums_1_1powder_condition =
[
    [ "powderCondition", "enumandroid_1_1app_1_1printerapp_1_1util_1_1ui_1_1enums_1_1powder_condition.html#ad0028886f2870c6862492d090034f758", null ],
    [ "getValue", "enumandroid_1_1app_1_1printerapp_1_1util_1_1ui_1_1enums_1_1powder_condition.html#a21de04dc8260a32c96a26d4e37add946", null ],
    [ "New", "enumandroid_1_1app_1_1printerapp_1_1util_1_1ui_1_1enums_1_1powder_condition.html#a6101be89adef9dad625b7d0db0772937", null ],
    [ "Reused", "enumandroid_1_1app_1_1printerapp_1_1util_1_1ui_1_1enums_1_1powder_condition.html#a224640f6935495a0c5ea973cc622b039", null ],
    [ "Used", "enumandroid_1_1app_1_1printerapp_1_1util_1_1ui_1_1enums_1_1powder_condition.html#a2b32cd0801db60c7ad7bd813d98989ad", null ]
];