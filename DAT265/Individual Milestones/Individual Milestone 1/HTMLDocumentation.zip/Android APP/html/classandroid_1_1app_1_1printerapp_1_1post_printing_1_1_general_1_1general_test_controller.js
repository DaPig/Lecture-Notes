var classandroid_1_1app_1_1printerapp_1_1post_printing_1_1_general_1_1general_test_controller =
[
    [ "generalTestController", "classandroid_1_1app_1_1printerapp_1_1post_printing_1_1_general_1_1general_test_controller.html#afa5c74bdb4e2ee2deb109557fa071707", null ],
    [ "changeContent", "classandroid_1_1app_1_1printerapp_1_1post_printing_1_1_general_1_1general_test_controller.html#ab622d393345d8f1ac22ae7d46e2f964f", null ],
    [ "didEnterStringData", "classandroid_1_1app_1_1printerapp_1_1post_printing_1_1_general_1_1general_test_controller.html#a19985054b01df7ae024584ae6979a0d0", null ],
    [ "displayPersonality", "classandroid_1_1app_1_1printerapp_1_1post_printing_1_1_general_1_1general_test_controller.html#a85d111aa9724a858cf892abb511d5925", null ],
    [ "getMapWithData", "classandroid_1_1app_1_1printerapp_1_1post_printing_1_1_general_1_1general_test_controller.html#abdace4a260321b8aeed3853805246e43", null ],
    [ "itemClicked", "classandroid_1_1app_1_1printerapp_1_1post_printing_1_1_general_1_1general_test_controller.html#a4d109b7025a19c5dd6caa74005fcda2c", null ],
    [ "sendMessageToUser", "classandroid_1_1app_1_1printerapp_1_1post_printing_1_1_general_1_1general_test_controller.html#a34133672d9c8f7d699b049d70147089c", null ]
];