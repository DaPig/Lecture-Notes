var dir_48aa82ff6ed5a1a3ac06176ebb4ebbc3 =
[
    [ "common", "dir_e9851f2896160956ec5d942290d54c8c.html", "dir_e9851f2896160956ec5d942290d54c8c" ],
    [ "license", "dir_dff8cea67112914f08629c1f44152445.html", "dir_dff8cea67112914f08629c1f44152445" ],
    [ "R.java", "app_2build_2generated_2source_2r_2debug_2com_2google_2android_2gms_2vision_2_r_8java.html", [
      [ "R", "classcom_1_1google_1_1android_1_1gms_1_1vision_1_1_r.html", null ]
    ] ]
];