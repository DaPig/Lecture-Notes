var dir_17c06613da8a2fae4e1c4f480f274db9 =
[
    [ "R.java", "materialdesignlibrary_2build_2generated_2source_2r_2debug_2android_2support_2v4_2_r_8java.html", [
      [ "R", "classandroid_1_1support_1_1v4_1_1_r.html", null ]
    ] ]
];