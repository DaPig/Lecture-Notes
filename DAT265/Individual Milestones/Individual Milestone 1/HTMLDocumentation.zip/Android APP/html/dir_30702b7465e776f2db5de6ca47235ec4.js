var dir_30702b7465e776f2db5de6ca47235ec4 =
[
    [ "partTestController.java", "part_test_controller_8java.html", [
      [ "partTestController", "classandroid_1_1app_1_1printerapp_1_1post_printing_1_1_retrieve_all_tests_1_1part_test_controller.html", "classandroid_1_1app_1_1printerapp_1_1post_printing_1_1_retrieve_all_tests_1_1part_test_controller" ]
    ] ],
    [ "partTestModel.java", "part_test_model_8java.html", [
      [ "partTestModel", "classandroid_1_1app_1_1printerapp_1_1post_printing_1_1_retrieve_all_tests_1_1part_test_model.html", "classandroid_1_1app_1_1printerapp_1_1post_printing_1_1_retrieve_all_tests_1_1part_test_model" ]
    ] ]
];