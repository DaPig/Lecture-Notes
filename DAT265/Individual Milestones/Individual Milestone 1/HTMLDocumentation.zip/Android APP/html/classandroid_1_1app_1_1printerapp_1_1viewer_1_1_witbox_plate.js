var classandroid_1_1app_1_1printerapp_1_1viewer_1_1_witbox_plate =
[
    [ "WitboxPlate", "classandroid_1_1app_1_1printerapp_1_1viewer_1_1_witbox_plate.html#a71f02c1c730bc0433e768e4d5475c497", null ],
    [ "draw", "classandroid_1_1app_1_1printerapp_1_1viewer_1_1_witbox_plate.html#a0e15801e297797fb07e3f3f660e23aa3", null ],
    [ "generatePlaneCoords", "classandroid_1_1app_1_1printerapp_1_1viewer_1_1_witbox_plate.html#acf24ac545a858ec78b08e9e12b2f7f10", null ]
];