var classandroid_1_1app_1_1printerapp_1_1backend_1_1models_1_1_role =
[
    [ "getId", "classandroid_1_1app_1_1printerapp_1_1backend_1_1models_1_1_role.html#a1ee54b49266ccf49c75407c058457d03", null ],
    [ "getName", "classandroid_1_1app_1_1printerapp_1_1backend_1_1models_1_1_role.html#af24e26161324575cec2658515c22dbab", null ],
    [ "getUsers", "classandroid_1_1app_1_1printerapp_1_1backend_1_1models_1_1_role.html#a3827d10d6cef752e25aa6e5773c13760", null ],
    [ "setId", "classandroid_1_1app_1_1printerapp_1_1backend_1_1models_1_1_role.html#aacdaa710cca34328f6143a5312a3803d", null ],
    [ "setName", "classandroid_1_1app_1_1printerapp_1_1backend_1_1models_1_1_role.html#a23fe169531b917bcfff9bbe25933640e", null ],
    [ "setUsers", "classandroid_1_1app_1_1printerapp_1_1backend_1_1models_1_1_role.html#a07d83fc3a1d6274fc4ef2f2dcf8b30d3", null ]
];