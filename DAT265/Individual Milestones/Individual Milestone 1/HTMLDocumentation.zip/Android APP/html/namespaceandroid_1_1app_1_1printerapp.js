var namespaceandroid_1_1app_1_1printerapp =
[
    [ "activities", "namespaceandroid_1_1app_1_1printerapp_1_1activities.html", "namespaceandroid_1_1app_1_1printerapp_1_1activities" ],
    [ "adapters", "namespaceandroid_1_1app_1_1printerapp_1_1adapters.html", "namespaceandroid_1_1app_1_1printerapp_1_1adapters" ],
    [ "backend", "namespaceandroid_1_1app_1_1printerapp_1_1backend.html", "namespaceandroid_1_1app_1_1printerapp_1_1backend" ],
    [ "displayingData", "namespaceandroid_1_1app_1_1printerapp_1_1displaying_data.html", "namespaceandroid_1_1app_1_1printerapp_1_1displaying_data" ],
    [ "homeScreen", "namespaceandroid_1_1app_1_1printerapp_1_1home_screen.html", "namespaceandroid_1_1app_1_1printerapp_1_1home_screen" ],
    [ "loginScreen", "namespaceandroid_1_1app_1_1printerapp_1_1login_screen.html", "namespaceandroid_1_1app_1_1printerapp_1_1login_screen" ],
    [ "magicsScreenshot", "namespaceandroid_1_1app_1_1printerapp_1_1magics_screenshot.html", "namespaceandroid_1_1app_1_1printerapp_1_1magics_screenshot" ],
    [ "postPrinting", "namespaceandroid_1_1app_1_1printerapp_1_1post_printing.html", "namespaceandroid_1_1app_1_1printerapp_1_1post_printing" ],
    [ "util", "namespaceandroid_1_1app_1_1printerapp_1_1util.html", "namespaceandroid_1_1app_1_1printerapp_1_1util" ],
    [ "viewer", "namespaceandroid_1_1app_1_1printerapp_1_1viewer.html", "namespaceandroid_1_1app_1_1printerapp_1_1viewer" ],
    [ "BuildConfig", "classandroid_1_1app_1_1printerapp_1_1_build_config.html", null ],
    [ "R", "classandroid_1_1app_1_1printerapp_1_1_r.html", null ],
    [ "StlSnapshooter", "classandroid_1_1app_1_1printerapp_1_1_stl_snapshooter.html", null ]
];