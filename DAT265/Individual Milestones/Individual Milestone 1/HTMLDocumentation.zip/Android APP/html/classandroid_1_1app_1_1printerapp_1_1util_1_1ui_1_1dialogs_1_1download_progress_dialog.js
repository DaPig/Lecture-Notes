var classandroid_1_1app_1_1printerapp_1_1util_1_1ui_1_1dialogs_1_1download_progress_dialog =
[
    [ "downloadProgressDialog", "classandroid_1_1app_1_1printerapp_1_1util_1_1ui_1_1dialogs_1_1download_progress_dialog.html#a0acea1aa79584a5b5e076d0b3fc706ff", null ],
    [ "dismiss", "classandroid_1_1app_1_1printerapp_1_1util_1_1ui_1_1dialogs_1_1download_progress_dialog.html#a687741a5e8d18c33577299e4b9193dab", null ],
    [ "isDialogShown", "classandroid_1_1app_1_1printerapp_1_1util_1_1ui_1_1dialogs_1_1download_progress_dialog.html#a141528b311327c9ac11161af46c3a63e", null ],
    [ "setProgressPercentage", "classandroid_1_1app_1_1printerapp_1_1util_1_1ui_1_1dialogs_1_1download_progress_dialog.html#a9245debad839dc0af11e4026c9af1c6d", null ],
    [ "show", "classandroid_1_1app_1_1printerapp_1_1util_1_1ui_1_1dialogs_1_1download_progress_dialog.html#a4f2310b300642b7998510507dde8ae8b", null ]
];