var dir_a63ab3c3059ba6ab5164a9606fab81de =
[
    [ "license", "dir_da1b3d1d1f6816734e38080c5c5d3bcd.html", "dir_da1b3d1d1f6816734e38080c5c5d3bcd" ],
    [ "R.java", "app_2build_2generated_2source_2r_2debug_2com_2google_2android_2gms_2tasks_2_r_8java.html", [
      [ "R", "classcom_1_1google_1_1android_1_1gms_1_1tasks_1_1_r.html", null ]
    ] ]
];