var classandroid_1_1app_1_1printerapp_1_1home_screen_1_1text_scanner_1_1text_scanner_model =
[
    [ "textScannerModel", "classandroid_1_1app_1_1printerapp_1_1home_screen_1_1text_scanner_1_1text_scanner_model.html#acd9b40d9ce5fd3beaf2f24685423da80", null ],
    [ "qrcodeReceived", "classandroid_1_1app_1_1printerapp_1_1home_screen_1_1text_scanner_1_1text_scanner_model.html#af96d063a34d1fa4f6f48d7e0e6fea5ed", null ]
];