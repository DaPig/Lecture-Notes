var annotated_dup =
[
    [ "android", "namespaceandroid.html", "namespaceandroid" ],
    [ "com", "namespacecom.html", "namespacecom" ],
    [ "it", "namespaceit.html", "namespaceit" ],
    [ "uk", "namespaceuk.html", "namespaceuk" ]
];