var namespaceandroid_1_1app_1_1printerapp_1_1home_screen =
[
    [ "QRScanner", "namespaceandroid_1_1app_1_1printerapp_1_1home_screen_1_1_q_r_scanner.html", "namespaceandroid_1_1app_1_1printerapp_1_1home_screen_1_1_q_r_scanner" ],
    [ "textScanner", "namespaceandroid_1_1app_1_1printerapp_1_1home_screen_1_1text_scanner.html", "namespaceandroid_1_1app_1_1printerapp_1_1home_screen_1_1text_scanner" ],
    [ "homeScreenActivity", "classandroid_1_1app_1_1printerapp_1_1home_screen_1_1home_screen_activity.html", "classandroid_1_1app_1_1printerapp_1_1home_screen_1_1home_screen_activity" ]
];