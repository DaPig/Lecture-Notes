var dir_000fa815e4d36eb93ac1cccd0b316b6f =
[
    [ "activities", "dir_5aa9c980f56e01e725dbfb69639ef03c.html", "dir_5aa9c980f56e01e725dbfb69639ef03c" ],
    [ "adapters", "dir_079a9fd183069656652cfdac63dcd229.html", "dir_079a9fd183069656652cfdac63dcd229" ],
    [ "backend", "dir_506e5feb611adf9728819a2f0e0a4454.html", "dir_506e5feb611adf9728819a2f0e0a4454" ],
    [ "displayingData", "dir_6a5ac9ffcbe71f75d4c4f3881cf39211.html", "dir_6a5ac9ffcbe71f75d4c4f3881cf39211" ],
    [ "homeScreen", "dir_70847d8541c352d284ea3f213d9a3575.html", "dir_70847d8541c352d284ea3f213d9a3575" ],
    [ "loginScreen", "dir_ed70cd811076d5d0359abd838920d0ef.html", "dir_ed70cd811076d5d0359abd838920d0ef" ],
    [ "magicsScreenshot", "dir_90ddda028dd684ac67855626223d2a44.html", "dir_90ddda028dd684ac67855626223d2a44" ],
    [ "postPrinting", "dir_d1a0c1720d45a78578b6955a7bdc421d.html", "dir_d1a0c1720d45a78578b6955a7bdc421d" ],
    [ "util", "dir_c91f948f20ab93eb0683fe921776689e.html", "dir_c91f948f20ab93eb0683fe921776689e" ],
    [ "viewer", "dir_0990c96970528754d47d27a05cd10210.html", "dir_0990c96970528754d47d27a05cd10210" ],
    [ "StlSnapshooter.java", "_stl_snapshooter_8java.html", [
      [ "StlSnapshooter", "classandroid_1_1app_1_1printerapp_1_1_stl_snapshooter.html", null ]
    ] ]
];