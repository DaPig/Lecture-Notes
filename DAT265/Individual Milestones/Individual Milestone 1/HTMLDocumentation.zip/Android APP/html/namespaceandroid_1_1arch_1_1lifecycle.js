var namespaceandroid_1_1arch_1_1lifecycle =
[
    [ "R", "classandroid_1_1arch_1_1lifecycle_1_1_r.html", null ]
];