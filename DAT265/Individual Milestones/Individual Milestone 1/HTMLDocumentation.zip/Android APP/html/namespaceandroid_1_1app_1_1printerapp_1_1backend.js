var namespaceandroid_1_1app_1_1printerapp_1_1backend =
[
    [ "models", "namespaceandroid_1_1app_1_1printerapp_1_1backend_1_1models.html", "namespaceandroid_1_1app_1_1printerapp_1_1backend_1_1models" ],
    [ "s3Downloader", "namespaceandroid_1_1app_1_1printerapp_1_1backend_1_1s3_downloader.html", "namespaceandroid_1_1app_1_1printerapp_1_1backend_1_1s3_downloader" ],
    [ "tokenManagement", "namespaceandroid_1_1app_1_1printerapp_1_1backend_1_1token_management.html", "namespaceandroid_1_1app_1_1printerapp_1_1backend_1_1token_management" ],
    [ "APIClient", "classandroid_1_1app_1_1printerapp_1_1backend_1_1_a_p_i_client.html", null ],
    [ "endpointDB", "interfaceandroid_1_1app_1_1printerapp_1_1backend_1_1endpoint_d_b.html", "interfaceandroid_1_1app_1_1printerapp_1_1backend_1_1endpoint_d_b" ]
];