var classandroid_1_1app_1_1printerapp_1_1backend_1_1models_1_1_create_stress_relieving =
[
    [ "getComment", "classandroid_1_1app_1_1printerapp_1_1backend_1_1models_1_1_create_stress_relieving.html#aed0acfa693fb2b253038b5c3084f4de8", null ],
    [ "getQrcode", "classandroid_1_1app_1_1printerapp_1_1backend_1_1models_1_1_create_stress_relieving.html#ab366e2ab0fa5d709a3d8804241a7ef38", null ],
    [ "getShieldingGas", "classandroid_1_1app_1_1printerapp_1_1backend_1_1models_1_1_create_stress_relieving.html#a4421f531f70d70ffc548a5f8a2564d4c", null ],
    [ "getTemperature", "classandroid_1_1app_1_1printerapp_1_1backend_1_1models_1_1_create_stress_relieving.html#aed0df217bf41a71e03baf6cde870b249", null ],
    [ "getTimeEvent", "classandroid_1_1app_1_1printerapp_1_1backend_1_1models_1_1_create_stress_relieving.html#a61c4532011099f1001b495b01ce60eb4", null ],
    [ "setComment", "classandroid_1_1app_1_1printerapp_1_1backend_1_1models_1_1_create_stress_relieving.html#ad791cdd94b20122a59616e50297585c3", null ],
    [ "setQrcode", "classandroid_1_1app_1_1printerapp_1_1backend_1_1models_1_1_create_stress_relieving.html#aa615e3f94ff72bb3023001478b54e663", null ],
    [ "setShieldingGas", "classandroid_1_1app_1_1printerapp_1_1backend_1_1models_1_1_create_stress_relieving.html#a61758afdc95bac89cb6bce42348b4fe0", null ],
    [ "setTemperature", "classandroid_1_1app_1_1printerapp_1_1backend_1_1models_1_1_create_stress_relieving.html#a71187c335728bb09d62908138fa69b0c", null ],
    [ "setTimeEvent", "classandroid_1_1app_1_1printerapp_1_1backend_1_1models_1_1_create_stress_relieving.html#a865f1cad07efd66014696103b1e14534", null ]
];