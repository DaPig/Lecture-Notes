var dir_aa4bf89fe66955b3c6cb835499ade7e1 =
[
    [ "R.java", "app_2build_2generated_2source_2r_2debug_2uk_2co_2androidalliance_2edgeeffectoverride_2_r_8java.html", [
      [ "R", "classuk_1_1co_1_1androidalliance_1_1edgeeffectoverride_1_1_r.html", null ]
    ] ]
];