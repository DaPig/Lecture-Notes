var dir_a5fa54a020f5a82c574049f8a223ce93 =
[
    [ "keyboardInterface.java", "keyboard_interface_8java.html", [
      [ "keyboardInterface", "interfaceandroid_1_1app_1_1printerapp_1_1util_1_1ui_1_1custom_keyboard_1_1keyboard_interface.html", "interfaceandroid_1_1app_1_1printerapp_1_1util_1_1ui_1_1custom_keyboard_1_1keyboard_interface" ]
    ] ],
    [ "scannerKeyboard.java", "scanner_keyboard_8java.html", [
      [ "scannerKeyboard", "classandroid_1_1app_1_1printerapp_1_1util_1_1ui_1_1custom_keyboard_1_1scanner_keyboard.html", "classandroid_1_1app_1_1printerapp_1_1util_1_1ui_1_1custom_keyboard_1_1scanner_keyboard" ]
    ] ]
];