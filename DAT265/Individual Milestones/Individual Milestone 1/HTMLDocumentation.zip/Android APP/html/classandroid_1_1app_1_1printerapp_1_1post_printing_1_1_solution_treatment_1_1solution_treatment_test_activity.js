var classandroid_1_1app_1_1printerapp_1_1post_printing_1_1_solution_treatment_1_1solution_treatment_test_activity =
[
    [ "cardViewPressed", "classandroid_1_1app_1_1printerapp_1_1post_printing_1_1_solution_treatment_1_1solution_treatment_test_activity.html#ab61f81bd6ce3438d3c72c3249b417a18", null ],
    [ "commentViewPressed", "classandroid_1_1app_1_1printerapp_1_1post_printing_1_1_solution_treatment_1_1solution_treatment_test_activity.html#a657f970caa2052236ff9a2d7ef44b946", null ],
    [ "createCards", "classandroid_1_1app_1_1printerapp_1_1post_printing_1_1_solution_treatment_1_1solution_treatment_test_activity.html#a3ede69746e852e3ff0f9e65fca3765b8", null ],
    [ "createNewSolutionTestDatabaseContent", "classandroid_1_1app_1_1printerapp_1_1post_printing_1_1_solution_treatment_1_1solution_treatment_test_activity.html#acfe3479f93ee8a9fa31e09a7750b0e8e", null ],
    [ "deleteCardInDatabaseContent", "classandroid_1_1app_1_1printerapp_1_1post_printing_1_1_solution_treatment_1_1solution_treatment_test_activity.html#a770315bdcbb8599c0aff174689ff4ed5", null ],
    [ "didEnterStringData", "classandroid_1_1app_1_1printerapp_1_1post_printing_1_1_solution_treatment_1_1solution_treatment_test_activity.html#adf3d9bb7dc0eadff217d569a773281e2", null ],
    [ "didEnterTime", "classandroid_1_1app_1_1printerapp_1_1post_printing_1_1_solution_treatment_1_1solution_treatment_test_activity.html#a84c0a65f360177737f176d8e289583de", null ],
    [ "fabPressed", "classandroid_1_1app_1_1printerapp_1_1post_printing_1_1_solution_treatment_1_1solution_treatment_test_activity.html#a6d05179f03006537bdc1c6e3b1f87808", null ],
    [ "getDatabaseContent", "classandroid_1_1app_1_1printerapp_1_1post_printing_1_1_solution_treatment_1_1solution_treatment_test_activity.html#aa2f09bda6a20ed11cd4ad4215d13368c", null ],
    [ "onCreate", "classandroid_1_1app_1_1printerapp_1_1post_printing_1_1_solution_treatment_1_1solution_treatment_test_activity.html#a12539ce5975130604b238186b760ebf8", null ],
    [ "tempButtonPressed", "classandroid_1_1app_1_1printerapp_1_1post_printing_1_1_solution_treatment_1_1solution_treatment_test_activity.html#a1455f9ab312e6bc1479fa12f9cd7b900", null ],
    [ "timeButtonPressed", "classandroid_1_1app_1_1printerapp_1_1post_printing_1_1_solution_treatment_1_1solution_treatment_test_activity.html#a324658ef71a1534d914e4cefd14c19cb", null ],
    [ "updateDatabaseContent", "classandroid_1_1app_1_1printerapp_1_1post_printing_1_1_solution_treatment_1_1solution_treatment_test_activity.html#a05155b6350d658fb2344502a615987c3", null ]
];