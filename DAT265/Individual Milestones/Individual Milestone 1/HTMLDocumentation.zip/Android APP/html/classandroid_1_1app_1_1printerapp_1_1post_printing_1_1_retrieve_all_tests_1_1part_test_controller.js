var classandroid_1_1app_1_1printerapp_1_1post_printing_1_1_retrieve_all_tests_1_1part_test_controller =
[
    [ "partTestController", "classandroid_1_1app_1_1printerapp_1_1post_printing_1_1_retrieve_all_tests_1_1part_test_controller.html#afbff4b0215261cf528e79ae0fb9aaacb", null ],
    [ "changeContent", "classandroid_1_1app_1_1printerapp_1_1post_printing_1_1_retrieve_all_tests_1_1part_test_controller.html#ada2b07c362401e386b86be8aa638a588", null ],
    [ "displayPersonality", "classandroid_1_1app_1_1printerapp_1_1post_printing_1_1_retrieve_all_tests_1_1part_test_controller.html#ae74543f5eb9e839c20b5f6607aba221d", null ],
    [ "getMapWithData", "classandroid_1_1app_1_1printerapp_1_1post_printing_1_1_retrieve_all_tests_1_1part_test_controller.html#adb1f642fb8d2459ca6ce4e02a1ef3b74", null ],
    [ "itemClicked", "classandroid_1_1app_1_1printerapp_1_1post_printing_1_1_retrieve_all_tests_1_1part_test_controller.html#a366c8816e8b6260cde39bce1e65c7ba3", null ],
    [ "sendMessageToUser", "classandroid_1_1app_1_1printerapp_1_1post_printing_1_1_retrieve_all_tests_1_1part_test_controller.html#ad2db8555ee224cc83535d0fb12f4dc10", null ]
];