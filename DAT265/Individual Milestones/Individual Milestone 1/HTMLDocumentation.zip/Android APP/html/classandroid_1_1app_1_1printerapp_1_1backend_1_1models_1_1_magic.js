var classandroid_1_1app_1_1printerapp_1_1backend_1_1models_1_1_magic =
[
    [ "getBuildId", "classandroid_1_1app_1_1printerapp_1_1backend_1_1models_1_1_magic.html#a2fa07c3cca216d55f9890ccf2ee7cc79", null ],
    [ "getFileName", "classandroid_1_1app_1_1printerapp_1_1backend_1_1models_1_1_magic.html#ae8193cf4f45f608c0765b7f805796f64", null ],
    [ "getMagicID", "classandroid_1_1app_1_1printerapp_1_1backend_1_1models_1_1_magic.html#a39a9ebec3ca2e80b1497b147d0556bec", null ],
    [ "getMagicScreenshot", "classandroid_1_1app_1_1printerapp_1_1backend_1_1models_1_1_magic.html#abdc616444483b3c4a6f512219b937042", null ],
    [ "setBuildId", "classandroid_1_1app_1_1printerapp_1_1backend_1_1models_1_1_magic.html#a5af676e9f393b3418e0633b0ef4a7250", null ],
    [ "setFileName", "classandroid_1_1app_1_1printerapp_1_1backend_1_1models_1_1_magic.html#ac30562e9f013fb6256258a1bcfc91f9b", null ],
    [ "setMagicID", "classandroid_1_1app_1_1printerapp_1_1backend_1_1models_1_1_magic.html#a23fb785094aed854f75e3c2d78ab2a32", null ],
    [ "setMagicScreenshot", "classandroid_1_1app_1_1printerapp_1_1backend_1_1models_1_1_magic.html#a30dc8e9eed0cc71bdce981bf10dd1101", null ]
];