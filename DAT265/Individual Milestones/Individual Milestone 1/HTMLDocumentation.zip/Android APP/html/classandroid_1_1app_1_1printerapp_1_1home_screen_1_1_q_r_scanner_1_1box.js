var classandroid_1_1app_1_1printerapp_1_1home_screen_1_1_q_r_scanner_1_1box =
[
    [ "box", "classandroid_1_1app_1_1printerapp_1_1home_screen_1_1_q_r_scanner_1_1box.html#a3eee65be32ef88be754703c604358757", null ],
    [ "onDraw", "classandroid_1_1app_1_1printerapp_1_1home_screen_1_1_q_r_scanner_1_1box.html#aa800ef775da86690aebe297efb3ad752", null ]
];