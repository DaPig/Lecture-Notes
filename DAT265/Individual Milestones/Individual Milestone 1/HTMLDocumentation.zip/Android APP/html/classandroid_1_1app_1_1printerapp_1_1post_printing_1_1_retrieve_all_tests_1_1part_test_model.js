var classandroid_1_1app_1_1printerapp_1_1post_printing_1_1_retrieve_all_tests_1_1part_test_model =
[
    [ "partTestModel", "classandroid_1_1app_1_1printerapp_1_1post_printing_1_1_retrieve_all_tests_1_1part_test_model.html#a4c8d0706b0f893fb751fddbea23e7652", null ],
    [ "getMapWithData", "classandroid_1_1app_1_1printerapp_1_1post_printing_1_1_retrieve_all_tests_1_1part_test_model.html#a8024ea36a537c5b9f529cc96a944a8d1", null ],
    [ "itemClicked", "classandroid_1_1app_1_1printerapp_1_1post_printing_1_1_retrieve_all_tests_1_1part_test_model.html#abec53078eef7b070a45e7edd3c6ab597", null ],
    [ "updateDatabaseContent", "classandroid_1_1app_1_1printerapp_1_1post_printing_1_1_retrieve_all_tests_1_1part_test_model.html#a9b50bca43d7e74581cf9d318a35fc6a4", null ]
];