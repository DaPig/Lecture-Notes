var dir_5aa9c980f56e01e725dbfb69639ef03c =
[
    [ "buildMainActivity.java", "build_main_activity_8java.html", [
      [ "buildMainActivity", "classandroid_1_1app_1_1printerapp_1_1activities_1_1build_main_activity.html", "classandroid_1_1app_1_1printerapp_1_1activities_1_1build_main_activity" ]
    ] ],
    [ "MainActivity.java", "_main_activity_8java.html", [
      [ "MainActivity", "classandroid_1_1app_1_1printerapp_1_1activities_1_1_main_activity.html", "classandroid_1_1app_1_1printerapp_1_1activities_1_1_main_activity" ]
    ] ],
    [ "STLViewerActivity.java", "_s_t_l_viewer_activity_8java.html", [
      [ "STLViewerActivity", "classandroid_1_1app_1_1printerapp_1_1activities_1_1_s_t_l_viewer_activity.html", "classandroid_1_1app_1_1printerapp_1_1activities_1_1_s_t_l_viewer_activity" ]
    ] ]
];