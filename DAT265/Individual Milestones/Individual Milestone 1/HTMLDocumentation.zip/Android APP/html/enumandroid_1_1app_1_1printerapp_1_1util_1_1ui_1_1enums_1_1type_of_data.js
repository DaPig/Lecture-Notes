var enumandroid_1_1app_1_1printerapp_1_1util_1_1ui_1_1enums_1_1type_of_data =
[
    [ "typeOfData", "enumandroid_1_1app_1_1printerapp_1_1util_1_1ui_1_1enums_1_1type_of_data.html#ac1db0eefca985c4e8b3ad33e8ec5f8aa", null ],
    [ "getValue", "enumandroid_1_1app_1_1printerapp_1_1util_1_1ui_1_1enums_1_1type_of_data.html#ab91d7be24f467bbb63eba885e6902a4f", null ],
    [ "buildData", "enumandroid_1_1app_1_1printerapp_1_1util_1_1ui_1_1enums_1_1type_of_data.html#a59aaae5bf34fd99ef2a60963f29ff335", null ],
    [ "buildHistory", "enumandroid_1_1app_1_1printerapp_1_1util_1_1ui_1_1enums_1_1type_of_data.html#a7168ea08777327da2ddc1819235df944", null ],
    [ "buildStls", "enumandroid_1_1app_1_1printerapp_1_1util_1_1ui_1_1enums_1_1type_of_data.html#a2a1bde572a7fbed38042691a2421e438", null ],
    [ "generalTest", "enumandroid_1_1app_1_1printerapp_1_1util_1_1ui_1_1enums_1_1type_of_data.html#a79c3b234db23cb7d1556506b29cb4168", null ],
    [ "partTests", "enumandroid_1_1app_1_1printerapp_1_1util_1_1ui_1_1enums_1_1type_of_data.html#a113416f4897077e901c16c43a70d3c6c", null ]
];