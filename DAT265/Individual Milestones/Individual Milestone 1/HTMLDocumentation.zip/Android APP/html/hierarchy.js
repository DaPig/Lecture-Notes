var hierarchy =
[
    [ "Adapter", null, [
      [ "android.app.printerapp.postPrinting.cardViewAdapter", "classandroid_1_1app_1_1printerapp_1_1post_printing_1_1card_view_adapter.html", null ],
      [ "android.app.printerapp.postPrinting.partTestCardViewAdapter", "classandroid_1_1app_1_1printerapp_1_1post_printing_1_1part_test_card_view_adapter.html", null ],
      [ "android.app.printerapp.postPrinting.StressRelieving.stressRelievingCardViewAdapter", "classandroid_1_1app_1_1printerapp_1_1post_printing_1_1_stress_relieving_1_1stress_relieving_card_view_adapter.html", null ]
    ] ],
    [ "it.sephiroth.android.library.widget.AdapterView< ListAdapter >", "classit_1_1sephiroth_1_1android_1_1library_1_1widget_1_1_adapter_view.html", [
      [ "it.sephiroth.android.library.widget.AbsHListView", "classit_1_1sephiroth_1_1android_1_1library_1_1widget_1_1_abs_h_list_view.html", [
        [ "it.sephiroth.android.library.widget.HListView", "classit_1_1sephiroth_1_1android_1_1library_1_1widget_1_1_h_list_view.html", [
          [ "it.sephiroth.android.library.widget.ExpandableHListView", "classit_1_1sephiroth_1_1android_1_1library_1_1widget_1_1_expandable_h_list_view.html", null ]
        ] ]
      ] ]
    ] ],
    [ "AdapterViewAdapterDataSetObserver", null, [
      [ "it.sephiroth.android.library.widget.AbsHListView.AdapterDataSetObserver", "classit_1_1sephiroth_1_1android_1_1library_1_1widget_1_1_abs_h_list_view_1_1_adapter_data_set_observer.html", null ]
    ] ],
    [ "android.app.printerapp.backend.models.AgingTreatmentTest", "classandroid_1_1app_1_1printerapp_1_1backend_1_1models_1_1_aging_treatment_test.html", null ],
    [ "AnimatorListener", null, [
      [ "com.material.widget.TabIndicator", "classcom_1_1material_1_1widget_1_1_tab_indicator.html", null ]
    ] ],
    [ "android.app.printerapp.backend.APIClient", "classandroid_1_1app_1_1printerapp_1_1backend_1_1_a_p_i_client.html", null ],
    [ "android.app.printerapp.util.ui.enums.APIExistMethodType", "enumandroid_1_1app_1_1printerapp_1_1util_1_1ui_1_1enums_1_1_a_p_i_exist_method_type.html", null ],
    [ "android.app.printerapp.BuildConfig", "classandroid_1_1app_1_1printerapp_1_1_build_config.html", null ],
    [ "it.sephiroth.android.library.BuildConfig", "classit_1_1sephiroth_1_1android_1_1library_1_1_build_config.html", null ],
    [ "com.material.widget.BuildConfig", "classcom_1_1material_1_1widget_1_1_build_config.html", null ],
    [ "android.app.printerapp.backend.models.BuildFiles", "classandroid_1_1app_1_1printerapp_1_1backend_1_1models_1_1_build_files.html", null ],
    [ "android.app.printerapp.util.ui.enums.bundleKeys", "enumandroid_1_1app_1_1printerapp_1_1util_1_1ui_1_1enums_1_1bundle_keys.html", null ],
    [ "Callback", null, [
      [ "it.sephiroth.android.library.util.v11.MultiChoiceModeListener", "interfaceit_1_1sephiroth_1_1android_1_1library_1_1util_1_1v11_1_1_multi_choice_mode_listener.html", [
        [ "it.sephiroth.android.library.util.v11.MultiChoiceModeWrapper", "classit_1_1sephiroth_1_1android_1_1library_1_1util_1_1v11_1_1_multi_choice_mode_wrapper.html", null ]
      ] ]
    ] ],
    [ "Callback", null, [
      [ "android.app.printerapp.homeScreen.QRScanner.QRreaderFragment", "classandroid_1_1app_1_1printerapp_1_1home_screen_1_1_q_r_scanner_1_1_q_rreader_fragment.html", null ]
    ] ],
    [ "android.app.printerapp.postPrinting.cardViewData", "classandroid_1_1app_1_1printerapp_1_1post_printing_1_1card_view_data.html", null ],
    [ "android.app.printerapp.viewer.Circles", "classandroid_1_1app_1_1printerapp_1_1viewer_1_1_circles.html", null ],
    [ "android.app.printerapp.backend.models.CreateAgingTest", "classandroid_1_1app_1_1printerapp_1_1backend_1_1models_1_1_create_aging_test.html", null ],
    [ "android.app.printerapp.backend.models.CreateHardeningTest", "classandroid_1_1app_1_1printerapp_1_1backend_1_1models_1_1_create_hardening_test.html", null ],
    [ "android.app.printerapp.backend.models.CreateSolutionTest", "classandroid_1_1app_1_1printerapp_1_1backend_1_1models_1_1_create_solution_test.html", null ],
    [ "android.app.printerapp.backend.models.CreateStressRelieving", "classandroid_1_1app_1_1printerapp_1_1backend_1_1models_1_1_create_stress_relieving.html", null ],
    [ "android.app.printerapp.backend.models.CreateTamperingTest", "classandroid_1_1app_1_1printerapp_1_1backend_1_1models_1_1_create_tampering_test.html", null ],
    [ "android.app.printerapp.util.ui.CustomPopupWindow", "classandroid_1_1app_1_1printerapp_1_1util_1_1ui_1_1_custom_popup_window.html", null ],
    [ "android.app.printerapp.displayingData.dataInterfaces", "interfaceandroid_1_1app_1_1printerapp_1_1displaying_data_1_1data_interfaces.html", null ],
    [ "android.app.printerapp.viewer.DataStorage", "classandroid_1_1app_1_1printerapp_1_1viewer_1_1_data_storage.html", null ],
    [ "android.app.printerapp.util.ui.dialogs.dialogComInterfaces.dateDialog", "interfaceandroid_1_1app_1_1printerapp_1_1util_1_1ui_1_1dialogs_1_1dialog_com_interfaces_1_1date_dialog.html", [
      [ "android.app.printerapp.displayingData.CMBuildData.buildDataController", "classandroid_1_1app_1_1printerapp_1_1displaying_data_1_1_c_m_build_data_1_1build_data_controller.html", null ]
    ] ],
    [ "android.app.printerapp.displayingData.dataInterfaces.dfControllerToViewInterface", "interfaceandroid_1_1app_1_1printerapp_1_1displaying_data_1_1data_interfaces_1_1df_controller_to_view_interface.html", [
      [ "android.app.printerapp.displayingData.dataFragment", "classandroid_1_1app_1_1printerapp_1_1displaying_data_1_1data_fragment.html", null ],
      [ "android.app.printerapp.displayingData.dataInterfaces.buildDataModelInterface", "interfaceandroid_1_1app_1_1printerapp_1_1displaying_data_1_1data_interfaces_1_1build_data_model_interface.html", [
        [ "android.app.printerapp.displayingData.CMBuildData.buildDataController", "classandroid_1_1app_1_1printerapp_1_1displaying_data_1_1_c_m_build_data_1_1build_data_controller.html", null ]
      ] ],
      [ "android.app.printerapp.displayingData.dataInterfaces.buildHistoryModelInterface", "interfaceandroid_1_1app_1_1printerapp_1_1displaying_data_1_1data_interfaces_1_1build_history_model_interface.html", [
        [ "android.app.printerapp.displayingData.CMBuildHistory.buildHistoryController", "classandroid_1_1app_1_1printerapp_1_1displaying_data_1_1_c_m_build_history_1_1build_history_controller.html", null ]
      ] ],
      [ "android.app.printerapp.displayingData.dataInterfaces.buildStlModelInterface", "interfaceandroid_1_1app_1_1printerapp_1_1displaying_data_1_1data_interfaces_1_1build_stl_model_interface.html", [
        [ "android.app.printerapp.displayingData.CMBuildStl.buildStlController", "classandroid_1_1app_1_1printerapp_1_1displaying_data_1_1_c_m_build_stl_1_1build_stl_controller.html", null ]
      ] ],
      [ "android.app.printerapp.displayingData.dataInterfaces.generalTestModelInterface", "interfaceandroid_1_1app_1_1printerapp_1_1displaying_data_1_1data_interfaces_1_1general_test_model_interface.html", [
        [ "android.app.printerapp.postPrinting.General.generalTestController", "classandroid_1_1app_1_1printerapp_1_1post_printing_1_1_general_1_1general_test_controller.html", null ]
      ] ],
      [ "android.app.printerapp.displayingData.dataInterfaces.partTestModelInterface", "interfaceandroid_1_1app_1_1printerapp_1_1displaying_data_1_1data_interfaces_1_1part_test_model_interface.html", [
        [ "android.app.printerapp.postPrinting.RetrieveAllTests.partTestController", "classandroid_1_1app_1_1printerapp_1_1post_printing_1_1_retrieve_all_tests_1_1part_test_controller.html", null ]
      ] ]
    ] ],
    [ "android.app.printerapp.displayingData.dataInterfaces.dfViewInterface", "interfaceandroid_1_1app_1_1printerapp_1_1displaying_data_1_1data_interfaces_1_1df_view_interface.html", [
      [ "android.app.printerapp.displayingData.CMBuildData.buildDataController", "classandroid_1_1app_1_1printerapp_1_1displaying_data_1_1_c_m_build_data_1_1build_data_controller.html", null ],
      [ "android.app.printerapp.displayingData.CMBuildHistory.buildHistoryController", "classandroid_1_1app_1_1printerapp_1_1displaying_data_1_1_c_m_build_history_1_1build_history_controller.html", null ],
      [ "android.app.printerapp.displayingData.CMBuildStl.buildStlController", "classandroid_1_1app_1_1printerapp_1_1displaying_data_1_1_c_m_build_stl_1_1build_stl_controller.html", null ],
      [ "android.app.printerapp.displayingData.dataInterfaces.buildDataControllerToModelInterface", "interfaceandroid_1_1app_1_1printerapp_1_1displaying_data_1_1data_interfaces_1_1build_data_controller_to_model_interface.html", [
        [ "android.app.printerapp.displayingData.CMBuildData.buildDataModel", "classandroid_1_1app_1_1printerapp_1_1displaying_data_1_1_c_m_build_data_1_1build_data_model.html", null ]
      ] ],
      [ "android.app.printerapp.displayingData.dataInterfaces.buildHistoryControllerToModelInterface", "interfaceandroid_1_1app_1_1printerapp_1_1displaying_data_1_1data_interfaces_1_1build_history_controller_to_model_interface.html", [
        [ "android.app.printerapp.displayingData.CMBuildHistory.buildHistoryModel", "classandroid_1_1app_1_1printerapp_1_1displaying_data_1_1_c_m_build_history_1_1build_history_model.html", null ]
      ] ],
      [ "android.app.printerapp.displayingData.dataInterfaces.buildStlControllerToModelInterface", "interfaceandroid_1_1app_1_1printerapp_1_1displaying_data_1_1data_interfaces_1_1build_stl_controller_to_model_interface.html", [
        [ "android.app.printerapp.displayingData.CMBuildStl.buildStlModel", "classandroid_1_1app_1_1printerapp_1_1displaying_data_1_1_c_m_build_stl_1_1build_stl_model.html", null ]
      ] ],
      [ "android.app.printerapp.displayingData.dataInterfaces.generalTestControllerToModelInterface", "interfaceandroid_1_1app_1_1printerapp_1_1displaying_data_1_1data_interfaces_1_1general_test_controller_to_model_interface.html", [
        [ "android.app.printerapp.postPrinting.General.generalTestModel", "classandroid_1_1app_1_1printerapp_1_1post_printing_1_1_general_1_1general_test_model.html", null ]
      ] ],
      [ "android.app.printerapp.displayingData.dataInterfaces.partTestControllerToModelInterface", "interfaceandroid_1_1app_1_1printerapp_1_1displaying_data_1_1data_interfaces_1_1part_test_controller_to_model_interface.html", [
        [ "android.app.printerapp.postPrinting.RetrieveAllTests.partTestModel", "classandroid_1_1app_1_1printerapp_1_1post_printing_1_1_retrieve_all_tests_1_1part_test_model.html", null ]
      ] ],
      [ "android.app.printerapp.postPrinting.General.generalTestController", "classandroid_1_1app_1_1printerapp_1_1post_printing_1_1_general_1_1general_test_controller.html", null ],
      [ "android.app.printerapp.postPrinting.RetrieveAllTests.partTestController", "classandroid_1_1app_1_1printerapp_1_1post_printing_1_1_retrieve_all_tests_1_1part_test_controller.html", null ]
    ] ],
    [ "android.app.printerapp.util.ui.dialogs.dialogComInterfaces", "interfaceandroid_1_1app_1_1printerapp_1_1util_1_1ui_1_1dialogs_1_1dialog_com_interfaces.html", null ],
    [ "android.app.printerapp.util.ui.dialogs.downloadProgressDialog", "classandroid_1_1app_1_1printerapp_1_1util_1_1ui_1_1dialogs_1_1download_progress_dialog.html", null ],
    [ "android.app.printerapp.util.ui.dialogs.EditTextDialog< T >", "classandroid_1_1app_1_1printerapp_1_1util_1_1ui_1_1dialogs_1_1_edit_text_dialog.html", null ],
    [ "android.app.printerapp.backend.endpointDB", "interfaceandroid_1_1app_1_1printerapp_1_1backend_1_1endpoint_d_b.html", null ],
    [ "android.app.printerapp.util.ui.enums", "classandroid_1_1app_1_1printerapp_1_1util_1_1ui_1_1enums.html", null ],
    [ "android.app.printerapp.util.ui.enums.FileDownloadType", "enumandroid_1_1app_1_1printerapp_1_1util_1_1ui_1_1enums_1_1_file_download_type.html", null ],
    [ "android.app.printerapp.util.ui.FileHelper", "classandroid_1_1app_1_1printerapp_1_1util_1_1ui_1_1_file_helper.html", null ],
    [ "android.app.printerapp.viewer.GcodeObject", "classandroid_1_1app_1_1printerapp_1_1viewer_1_1_gcode_object.html", null ],
    [ "android.app.printerapp.backend.models.GeneralTest", "classandroid_1_1app_1_1printerapp_1_1backend_1_1models_1_1_general_test.html", null ],
    [ "android.app.printerapp.util.ui.enums.generalTests", "enumandroid_1_1app_1_1printerapp_1_1util_1_1ui_1_1enums_1_1general_tests.html", null ],
    [ "android.app.printerapp.viewer.Geometry", "classandroid_1_1app_1_1printerapp_1_1viewer_1_1_geometry.html", null ],
    [ "android.app.printerapp.util.ui.enums.grantTypes", "enumandroid_1_1app_1_1printerapp_1_1util_1_1ui_1_1enums_1_1grant_types.html", null ],
    [ "android.app.printerapp.backend.models.HardeningTest", "classandroid_1_1app_1_1printerapp_1_1backend_1_1models_1_1_hardening_test.html", null ],
    [ "HorizontalScrollView", null, [
      [ "com.material.widget.TabIndicator", "classcom_1_1material_1_1widget_1_1_tab_indicator.html", null ]
    ] ],
    [ "com.material.widget.ActionSheet.Item", "classcom_1_1material_1_1widget_1_1_action_sheet_1_1_item.html", null ],
    [ "android.app.printerapp.util.ui.customKeyboard.keyboardInterface", "interfaceandroid_1_1app_1_1printerapp_1_1util_1_1ui_1_1custom_keyboard_1_1keyboard_interface.html", [
      [ "android.app.printerapp.homeScreen.textScanner.textScannerFragment", "classandroid_1_1app_1_1printerapp_1_1home_screen_1_1text_scanner_1_1text_scanner_fragment.html", null ]
    ] ],
    [ "android.app.printerapp.util.ui.Log", "classandroid_1_1app_1_1printerapp_1_1util_1_1ui_1_1_log.html", null ],
    [ "android.app.printerapp.loginScreen.loginScreenController", "classandroid_1_1app_1_1printerapp_1_1login_screen_1_1login_screen_controller.html", null ],
    [ "android.app.printerapp.loginScreen.loginScreenInterfaces", "classandroid_1_1app_1_1printerapp_1_1login_screen_1_1login_screen_interfaces.html", null ],
    [ "android.app.printerapp.backend.models.Magic", "classandroid_1_1app_1_1printerapp_1_1backend_1_1models_1_1_magic.html", null ],
    [ "it.sephiroth.android.library.util.MathUtils", "classit_1_1sephiroth_1_1android_1_1library_1_1util_1_1_math_utils.html", null ],
    [ "android.app.printerapp.backend.models.NumberOfTests", "classandroid_1_1app_1_1printerapp_1_1backend_1_1models_1_1_number_of_tests.html", null ],
    [ "it.sephiroth.android.library.widget.ExpandableHListView.OnChildClickListener", "interfaceit_1_1sephiroth_1_1android_1_1library_1_1widget_1_1_expandable_h_list_view_1_1_on_child_click_listener.html", null ],
    [ "OnClickListener", null, [
      [ "android.app.printerapp.loginScreen.loginScreenActivity", "classandroid_1_1app_1_1printerapp_1_1login_screen_1_1login_screen_activity.html", null ],
      [ "android.app.printerapp.util.ui.customKeyboard.scannerKeyboard< T >", "classandroid_1_1app_1_1printerapp_1_1util_1_1ui_1_1custom_keyboard_1_1scanner_keyboard.html", null ]
    ] ],
    [ "OnDateSetListener", null, [
      [ "android.app.printerapp.util.ui.dialogs.DatePickerFragment< T >", "classandroid_1_1app_1_1printerapp_1_1util_1_1ui_1_1dialogs_1_1_date_picker_fragment.html", null ]
    ] ],
    [ "OnGlobalLayoutListener", null, [
      [ "it.sephiroth.android.library.widget.AbsHListView", "classit_1_1sephiroth_1_1android_1_1library_1_1widget_1_1_abs_h_list_view.html", null ]
    ] ],
    [ "it.sephiroth.android.library.widget.ExpandableHListView.OnGroupClickListener", "interfaceit_1_1sephiroth_1_1android_1_1library_1_1widget_1_1_expandable_h_list_view_1_1_on_group_click_listener.html", null ],
    [ "it.sephiroth.android.library.widget.ExpandableHListView.OnGroupCollapseListener", "interfaceit_1_1sephiroth_1_1android_1_1library_1_1widget_1_1_expandable_h_list_view_1_1_on_group_collapse_listener.html", null ],
    [ "it.sephiroth.android.library.widget.ExpandableHListView.OnGroupExpandListener", "interfaceit_1_1sephiroth_1_1android_1_1library_1_1widget_1_1_expandable_h_list_view_1_1_on_group_expand_listener.html", null ],
    [ "OnItemClickListener", null, [
      [ "android.app.printerapp.displayingData.dataFragment", "classandroid_1_1app_1_1printerapp_1_1displaying_data_1_1data_fragment.html", null ]
    ] ],
    [ "it.sephiroth.android.library.widget.AdapterView< T extends Adapter >.OnItemClickListener", "interfaceit_1_1sephiroth_1_1android_1_1library_1_1widget_1_1_adapter_view_1_1_on_item_click_listener.html", null ],
    [ "it.sephiroth.android.library.widget.AdapterView< T extends Adapter >.OnItemLongClickListener", "interfaceit_1_1sephiroth_1_1android_1_1library_1_1widget_1_1_adapter_view_1_1_on_item_long_click_listener.html", null ],
    [ "it.sephiroth.android.library.widget.AdapterView< T extends Adapter >.OnItemSelectedListener", "interfaceit_1_1sephiroth_1_1android_1_1library_1_1widget_1_1_adapter_view_1_1_on_item_selected_listener.html", null ],
    [ "com.material.widget.TabIndicator.OnNavListener", "interfacecom_1_1material_1_1widget_1_1_tab_indicator_1_1_on_nav_listener.html", null ],
    [ "OnPageChangeListener", null, [
      [ "android.app.printerapp.activities.buildMainActivity", "classandroid_1_1app_1_1printerapp_1_1activities_1_1build_main_activity.html", null ],
      [ "android.app.printerapp.homeScreen.homeScreenActivity", "classandroid_1_1app_1_1printerapp_1_1home_screen_1_1home_screen_activity.html", null ]
    ] ],
    [ "it.sephiroth.android.library.widget.AbsHListView.OnScrollListener", "interfaceit_1_1sephiroth_1_1android_1_1library_1_1widget_1_1_abs_h_list_view_1_1_on_scroll_listener.html", null ],
    [ "com.material.widget.TabIndicator.OnSelectTabListener", "interfacecom_1_1material_1_1widget_1_1_tab_indicator_1_1_on_select_tab_listener.html", null ],
    [ "OnTimeSetListener", null, [
      [ "android.app.printerapp.util.ui.dialogs.TimePickerFragment< T >", "classandroid_1_1app_1_1printerapp_1_1util_1_1ui_1_1dialogs_1_1_time_picker_fragment.html", null ]
    ] ],
    [ "OnTouchModeChangeListener", null, [
      [ "it.sephiroth.android.library.widget.AbsHListView", "classit_1_1sephiroth_1_1android_1_1library_1_1widget_1_1_abs_h_list_view.html", null ]
    ] ],
    [ "android.app.printerapp.util.ui.CustomEditableSlider.OnValueChangedListener", "interfaceandroid_1_1app_1_1printerapp_1_1util_1_1ui_1_1_custom_editable_slider_1_1_on_value_changed_listener.html", null ],
    [ "it.sephiroth.android.library.widget.OverScroller", "classit_1_1sephiroth_1_1android_1_1library_1_1widget_1_1_over_scroller.html", null ],
    [ "PageTransformer", null, [
      [ "android.app.printerapp.util.ui.viewPagerAnimation", "classandroid_1_1app_1_1printerapp_1_1util_1_1ui_1_1view_pager_animation.html", null ]
    ] ],
    [ "android.app.printerapp.backend.models.Part", "classandroid_1_1app_1_1printerapp_1_1backend_1_1models_1_1_part.html", null ],
    [ "android.app.printerapp.backend.models.PartFile", "classandroid_1_1app_1_1printerapp_1_1backend_1_1models_1_1_part_file.html", null ],
    [ "android.app.printerapp.postPrinting.partTestCardViewData", "classandroid_1_1app_1_1printerapp_1_1post_printing_1_1part_test_card_view_data.html", null ],
    [ "android.app.printerapp.util.ui.enums.postPrintingTests", "enumandroid_1_1app_1_1printerapp_1_1util_1_1ui_1_1enums_1_1post_printing_tests.html", null ],
    [ "android.app.printerapp.util.ui.enums.powderCondition", "enumandroid_1_1app_1_1printerapp_1_1util_1_1ui_1_1enums_1_1powder_condition.html", null ],
    [ "android.app.printerapp.backend.models.PrintingData", "classandroid_1_1app_1_1printerapp_1_1backend_1_1models_1_1_printing_data.html", null ],
    [ "android.app.printerapp.util.ui.enums.printingData", "enumandroid_1_1app_1_1printerapp_1_1util_1_1ui_1_1enums_1_1printing_data.html", null ],
    [ "android.app.printerapp.util.ui.enums.qrCodeType", "enumandroid_1_1app_1_1printerapp_1_1util_1_1ui_1_1enums_1_1qr_code_type.html", null ],
    [ "android.app.printerapp.homeScreen.QRScanner.QRreaderInterface", "interfaceandroid_1_1app_1_1printerapp_1_1home_screen_1_1_q_r_scanner_1_1_q_rreader_interface.html", null ],
    [ "com.google.android.gms.tasks.license.R", "classcom_1_1google_1_1android_1_1gms_1_1tasks_1_1license_1_1_r.html", null ],
    [ "android.support.mediacompat.R", "classandroid_1_1support_1_1mediacompat_1_1_r.html", null ],
    [ "com.rd.pageindicatorview.R", "classcom_1_1rd_1_1pageindicatorview_1_1_r.html", null ],
    [ "android.support.coreutils.R", "classandroid_1_1support_1_1coreutils_1_1_r.html", null ],
    [ "android.app.printerapp.R", "classandroid_1_1app_1_1printerapp_1_1_r.html", null ],
    [ "android.support.constraint.R", "classandroid_1_1support_1_1constraint_1_1_r.html", null ],
    [ "android.support.v7.recyclerview.R", "classandroid_1_1support_1_1v7_1_1recyclerview_1_1_r.html", null ],
    [ "com.google.android.gms.R", "classcom_1_1google_1_1android_1_1gms_1_1_r.html", null ],
    [ "android.support.graphics.drawable.animated.R", "classandroid_1_1support_1_1graphics_1_1drawable_1_1animated_1_1_r.html", null ],
    [ "android.support.compat.R", "classandroid_1_1support_1_1compat_1_1_r.html", null ],
    [ "com.alertdialogpro.material.R", "classcom_1_1alertdialogpro_1_1material_1_1_r.html", null ],
    [ "com.rengwuxian.materialedittext.R", "classcom_1_1rengwuxian_1_1materialedittext_1_1_r.html", null ],
    [ "android.support.coreui.R", "classandroid_1_1support_1_1coreui_1_1_r.html", null ],
    [ "uk.co.androidalliance.edgeeffectoverride.R", "classuk_1_1co_1_1androidalliance_1_1edgeeffectoverride_1_1_r.html", null ],
    [ "com.google.android.gms.tasks.R", "classcom_1_1google_1_1android_1_1gms_1_1tasks_1_1_r.html", null ],
    [ "com.gc.materialdesign.R", "classcom_1_1gc_1_1materialdesign_1_1_r.html", null ],
    [ "com.alertdialogpro.R", "classcom_1_1alertdialogpro_1_1_r.html", null ],
    [ "com.google.android.gms.base.license.R", "classcom_1_1google_1_1android_1_1gms_1_1base_1_1license_1_1_r.html", null ],
    [ "com.google.android.gms.base.R", "classcom_1_1google_1_1android_1_1gms_1_1base_1_1_r.html", null ],
    [ "com.xw.repo.bubbleseekbar.R", "classcom_1_1xw_1_1repo_1_1bubbleseekbar_1_1_r.html", null ],
    [ "com.google.android.gms.common.license.R", "classcom_1_1google_1_1android_1_1gms_1_1common_1_1license_1_1_r.html", null ],
    [ "com.google.android.gms.vision.common.license.R", "classcom_1_1google_1_1android_1_1gms_1_1vision_1_1common_1_1license_1_1_r.html", null ],
    [ "com.google.android.gms.vision.license.R", "classcom_1_1google_1_1android_1_1gms_1_1vision_1_1license_1_1_r.html", null ],
    [ "android.support.v4.R", "classandroid_1_1support_1_1v4_1_1_r.html", null ],
    [ "com.material.widget.R", "classcom_1_1material_1_1widget_1_1_r.html", null ],
    [ "android.support.graphics.drawable.R", "classandroid_1_1support_1_1graphics_1_1drawable_1_1_r.html", null ],
    [ "com.pnikosis.materialishprogress.R", "classcom_1_1pnikosis_1_1materialishprogress_1_1_r.html", null ],
    [ "android.support.v7.cardview.R", "classandroid_1_1support_1_1v7_1_1cardview_1_1_r.html", null ],
    [ "android.arch.lifecycle.R", "classandroid_1_1arch_1_1lifecycle_1_1_r.html", null ],
    [ "com.google.android.gms.vision.R", "classcom_1_1google_1_1android_1_1gms_1_1vision_1_1_r.html", null ],
    [ "it.sephiroth.android.library.R", "classit_1_1sephiroth_1_1android_1_1library_1_1_r.html", null ],
    [ "android.support.v7.appcompat.R", "classandroid_1_1support_1_1v7_1_1appcompat_1_1_r.html", null ],
    [ "android.support.fragment.R", "classandroid_1_1support_1_1fragment_1_1_r.html", null ],
    [ "android.app.printerapp.homeScreen.QRScanner.QRreaderInterface.rControllerToViewInterface", "interfaceandroid_1_1app_1_1printerapp_1_1home_screen_1_1_q_r_scanner_1_1_q_rreader_interface_1_1r_controller_to_view_interface.html", [
      [ "android.app.printerapp.homeScreen.QRScanner.QRreaderFragment", "classandroid_1_1app_1_1printerapp_1_1home_screen_1_1_q_r_scanner_1_1_q_rreader_fragment.html", null ]
    ] ],
    [ "it.sephiroth.android.library.widget.AbsHListView.RecycleBin", "classit_1_1sephiroth_1_1android_1_1library_1_1widget_1_1_abs_h_list_view_1_1_recycle_bin.html", null ],
    [ "Renderer", null, [
      [ "android.app.printerapp.viewer.ViewerRenderer", "classandroid_1_1app_1_1printerapp_1_1viewer_1_1_viewer_renderer.html", null ]
    ] ],
    [ "android.app.printerapp.backend.models.Role", "classandroid_1_1app_1_1printerapp_1_1backend_1_1models_1_1_role.html", null ],
    [ "Runnable", null, [
      [ "it.sephiroth.android.library.widget.AbsHListView.PositionScroller", "classit_1_1sephiroth_1_1android_1_1library_1_1widget_1_1_abs_h_list_view_1_1_position_scroller.html", null ]
    ] ],
    [ "android.app.printerapp.homeScreen.QRScanner.QRreaderInterface.rViewInterface", "interfaceandroid_1_1app_1_1printerapp_1_1home_screen_1_1_q_r_scanner_1_1_q_rreader_interface_1_1r_view_interface.html", [
      [ "android.app.printerapp.homeScreen.QRScanner.QRreaderController", "classandroid_1_1app_1_1printerapp_1_1home_screen_1_1_q_r_scanner_1_1_q_rreader_controller.html", null ]
    ] ],
    [ "android.app.printerapp.backend.s3Downloader.S3Download< T >", "classandroid_1_1app_1_1printerapp_1_1backend_1_1s3_downloader_1_1_s3_download.html", null ],
    [ "android.app.printerapp.backend.s3Downloader.S3Download< android.app.printerapp.magicsScreenshot.magicsScreenshotActivity >", "classandroid_1_1app_1_1printerapp_1_1backend_1_1s3_downloader_1_1_s3_download.html", null ],
    [ "android.app.printerapp.backend.s3Downloader.s3downloadInterface", "interfaceandroid_1_1app_1_1printerapp_1_1backend_1_1s3_downloader_1_1s3download_interface.html", [
      [ "android.app.printerapp.displayingData.CMBuildStl.buildStlModel", "classandroid_1_1app_1_1printerapp_1_1displaying_data_1_1_c_m_build_stl_1_1build_stl_model.html", null ],
      [ "android.app.printerapp.magicsScreenshot.magicsScreenshotActivity", "classandroid_1_1app_1_1printerapp_1_1magics_screenshot_1_1magics_screenshot_activity.html", null ],
      [ "android.app.printerapp.viewer.ViewerMainFragment", "classandroid_1_1app_1_1printerapp_1_1viewer_1_1_viewer_main_fragment.html", null ]
    ] ],
    [ "it.sephiroth.android.library.widget.AbsHListView.SelectionBoundsAdjuster", "interfaceit_1_1sephiroth_1_1android_1_1library_1_1widget_1_1_abs_h_list_view_1_1_selection_bounds_adjuster.html", null ],
    [ "android.app.printerapp.util.ui.dialogs.singleItemPicker< T >", "classandroid_1_1app_1_1printerapp_1_1util_1_1ui_1_1dialogs_1_1single_item_picker.html", null ],
    [ "android.app.printerapp.util.ui.dialogs.dialogComInterfaces.singleItemPowderConditionPicker", "interfaceandroid_1_1app_1_1printerapp_1_1util_1_1ui_1_1dialogs_1_1dialog_com_interfaces_1_1single_item_powder_condition_picker.html", [
      [ "android.app.printerapp.displayingData.CMBuildData.buildDataController", "classandroid_1_1app_1_1printerapp_1_1displaying_data_1_1_c_m_build_data_1_1build_data_controller.html", null ]
    ] ],
    [ "android.app.printerapp.backend.models.SolutionTreatmentTest", "classandroid_1_1app_1_1printerapp_1_1backend_1_1models_1_1_solution_treatment_test.html", null ],
    [ "android.app.printerapp.viewer.StlFile", "classandroid_1_1app_1_1printerapp_1_1viewer_1_1_stl_file.html", null ],
    [ "android.app.printerapp.viewer.StlObject", "classandroid_1_1app_1_1printerapp_1_1viewer_1_1_stl_object.html", null ],
    [ "android.app.printerapp.StlSnapshooter", "classandroid_1_1app_1_1printerapp_1_1_stl_snapshooter.html", null ],
    [ "android.app.printerapp.backend.models.StressRelieving", "classandroid_1_1app_1_1printerapp_1_1backend_1_1models_1_1_stress_relieving.html", null ],
    [ "android.app.printerapp.postPrinting.StressRelieving.stressRelievingCardViewData", "classandroid_1_1app_1_1printerapp_1_1post_printing_1_1_stress_relieving_1_1stress_relieving_card_view_data.html", null ],
    [ "android.app.printerapp.util.ui.dialogs.dialogComInterfaces.stringDialog", "interfaceandroid_1_1app_1_1printerapp_1_1util_1_1ui_1_1dialogs_1_1dialog_com_interfaces_1_1string_dialog.html", [
      [ "android.app.printerapp.displayingData.CMBuildData.buildDataController", "classandroid_1_1app_1_1printerapp_1_1displaying_data_1_1_c_m_build_data_1_1build_data_controller.html", null ],
      [ "android.app.printerapp.postPrinting.AgingTreatment.agingTreatmentTestActivity", "classandroid_1_1app_1_1printerapp_1_1post_printing_1_1_aging_treatment_1_1aging_treatment_test_activity.html", null ],
      [ "android.app.printerapp.postPrinting.General.generalTestController", "classandroid_1_1app_1_1printerapp_1_1post_printing_1_1_general_1_1general_test_controller.html", null ],
      [ "android.app.printerapp.postPrinting.Hardening.hardeningTestActivity", "classandroid_1_1app_1_1printerapp_1_1post_printing_1_1_hardening_1_1hardening_test_activity.html", null ],
      [ "android.app.printerapp.postPrinting.postPrintingTestActivity", "classandroid_1_1app_1_1printerapp_1_1post_printing_1_1post_printing_test_activity.html", null ],
      [ "android.app.printerapp.postPrinting.SolutionTreatment.solutionTreatmentTestActivity", "classandroid_1_1app_1_1printerapp_1_1post_printing_1_1_solution_treatment_1_1solution_treatment_test_activity.html", null ],
      [ "android.app.printerapp.postPrinting.StressRelieving.stressRelievingTestActivity", "classandroid_1_1app_1_1printerapp_1_1post_printing_1_1_stress_relieving_1_1stress_relieving_test_activity.html", null ],
      [ "android.app.printerapp.postPrinting.Tampering.tamperingTestActivity", "classandroid_1_1app_1_1printerapp_1_1post_printing_1_1_tampering_1_1tampering_test_activity.html", null ]
    ] ],
    [ "com.material.widget.TabIndicator.TabResourceProvider", "interfacecom_1_1material_1_1widget_1_1_tab_indicator_1_1_tab_resource_provider.html", null ],
    [ "android.app.printerapp.backend.models.TamperingTest", "classandroid_1_1app_1_1printerapp_1_1backend_1_1models_1_1_tampering_test.html", null ],
    [ "android.app.printerapp.homeScreen.textScanner.textScannerInterfaces", "interfaceandroid_1_1app_1_1printerapp_1_1home_screen_1_1text_scanner_1_1text_scanner_interfaces.html", null ],
    [ "android.app.printerapp.util.ui.dialogs.dialogComInterfaces.timeDialog", "interfaceandroid_1_1app_1_1printerapp_1_1util_1_1ui_1_1dialogs_1_1dialog_com_interfaces_1_1time_dialog.html", [
      [ "android.app.printerapp.displayingData.CMBuildData.buildDataController", "classandroid_1_1app_1_1printerapp_1_1displaying_data_1_1_c_m_build_data_1_1build_data_controller.html", null ],
      [ "android.app.printerapp.postPrinting.AgingTreatment.agingTreatmentTestActivity", "classandroid_1_1app_1_1printerapp_1_1post_printing_1_1_aging_treatment_1_1aging_treatment_test_activity.html", null ],
      [ "android.app.printerapp.postPrinting.Hardening.hardeningTestActivity", "classandroid_1_1app_1_1printerapp_1_1post_printing_1_1_hardening_1_1hardening_test_activity.html", null ],
      [ "android.app.printerapp.postPrinting.postPrintingTestActivity", "classandroid_1_1app_1_1printerapp_1_1post_printing_1_1post_printing_test_activity.html", null ],
      [ "android.app.printerapp.postPrinting.SolutionTreatment.solutionTreatmentTestActivity", "classandroid_1_1app_1_1printerapp_1_1post_printing_1_1_solution_treatment_1_1solution_treatment_test_activity.html", null ],
      [ "android.app.printerapp.postPrinting.StressRelieving.stressRelievingTestActivity", "classandroid_1_1app_1_1printerapp_1_1post_printing_1_1_stress_relieving_1_1stress_relieving_test_activity.html", null ],
      [ "android.app.printerapp.postPrinting.Tampering.tamperingTestActivity", "classandroid_1_1app_1_1printerapp_1_1post_printing_1_1_tampering_1_1tampering_test_activity.html", null ]
    ] ],
    [ "android.app.printerapp.backend.models.Token", "classandroid_1_1app_1_1printerapp_1_1backend_1_1models_1_1_token.html", null ],
    [ "android.app.printerapp.backend.tokenManagement.tokenInterfaces", "interfaceandroid_1_1app_1_1printerapp_1_1backend_1_1token_management_1_1token_interfaces.html", [
      [ "android.app.printerapp.loginScreen.loginScreenModel", "classandroid_1_1app_1_1printerapp_1_1login_screen_1_1login_screen_model.html", null ]
    ] ],
    [ "android.app.printerapp.backend.tokenManagement.TokenManager< T >", "classandroid_1_1app_1_1printerapp_1_1backend_1_1token_management_1_1_token_manager.html", null ],
    [ "android.app.printerapp.homeScreen.textScanner.textScannerInterfaces.tsSharedRequestInterface", "interfaceandroid_1_1app_1_1printerapp_1_1home_screen_1_1text_scanner_1_1text_scanner_interfaces_1_1ts_shared_request_interface.html", [
      [ "android.app.printerapp.homeScreen.textScanner.textScannerInterfaces.tsControllerToModelInterface", "interfaceandroid_1_1app_1_1printerapp_1_1home_screen_1_1text_scanner_1_1text_scanner_interfaces_de3b35cdd0fa8ad0b8b26702cf295724.html", [
        [ "android.app.printerapp.homeScreen.textScanner.textScannerModel", "classandroid_1_1app_1_1printerapp_1_1home_screen_1_1text_scanner_1_1text_scanner_model.html", null ]
      ] ],
      [ "android.app.printerapp.homeScreen.textScanner.textScannerInterfaces.tsViewInterface", "interfaceandroid_1_1app_1_1printerapp_1_1home_screen_1_1text_scanner_1_1text_scanner_interfaces_1_1ts_view_interface.html", [
        [ "android.app.printerapp.homeScreen.textScanner.textScannerController", "classandroid_1_1app_1_1printerapp_1_1home_screen_1_1text_scanner_1_1text_scanner_controller.html", null ]
      ] ]
    ] ],
    [ "android.app.printerapp.homeScreen.textScanner.textScannerInterfaces.tsSharedResultResultInterface", "interfaceandroid_1_1app_1_1printerapp_1_1home_screen_1_1text_scanner_1_1text_scanner_interfaces_a8faba9f34814e49ceb746c81043a30b.html", [
      [ "android.app.printerapp.homeScreen.textScanner.textScannerInterfaces.tsControllerToViewInterface", "interfaceandroid_1_1app_1_1printerapp_1_1home_screen_1_1text_scanner_1_1text_scanner_interfaces_97cbbd0fb3a94b6eca231c4c2c575d2f.html", [
        [ "android.app.printerapp.homeScreen.textScanner.textScannerFragment", "classandroid_1_1app_1_1printerapp_1_1home_screen_1_1text_scanner_1_1text_scanner_fragment.html", null ]
      ] ],
      [ "android.app.printerapp.homeScreen.textScanner.textScannerInterfaces.tsModelInterface", "interfaceandroid_1_1app_1_1printerapp_1_1home_screen_1_1text_scanner_1_1text_scanner_interfaces_1_1ts_model_interface.html", [
        [ "android.app.printerapp.homeScreen.QRScanner.QRreaderController", "classandroid_1_1app_1_1printerapp_1_1home_screen_1_1_q_r_scanner_1_1_q_rreader_controller.html", null ],
        [ "android.app.printerapp.homeScreen.textScanner.textScannerController", "classandroid_1_1app_1_1printerapp_1_1home_screen_1_1text_scanner_1_1text_scanner_controller.html", null ]
      ] ]
    ] ],
    [ "android.app.printerapp.util.ui.enums.typeOfData", "enumandroid_1_1app_1_1printerapp_1_1util_1_1ui_1_1enums_1_1type_of_data.html", null ],
    [ "android.app.printerapp.backend.models.UpdateAgingTreatmentTest", "classandroid_1_1app_1_1printerapp_1_1backend_1_1models_1_1_update_aging_treatment_test.html", null ],
    [ "android.app.printerapp.backend.models.UpdateGeneral", "classandroid_1_1app_1_1printerapp_1_1backend_1_1models_1_1_update_general.html", null ],
    [ "android.app.printerapp.backend.models.UpdateHardening", "classandroid_1_1app_1_1printerapp_1_1backend_1_1models_1_1_update_hardening.html", null ],
    [ "android.app.printerapp.backend.models.UpdateSolutionTreatment", "classandroid_1_1app_1_1printerapp_1_1backend_1_1models_1_1_update_solution_treatment.html", null ],
    [ "android.app.printerapp.backend.models.UpdateStressRelieving", "classandroid_1_1app_1_1printerapp_1_1backend_1_1models_1_1_update_stress_relieving.html", null ],
    [ "android.app.printerapp.backend.models.UpdateTampering", "classandroid_1_1app_1_1printerapp_1_1backend_1_1models_1_1_update_tampering.html", null ],
    [ "android.app.printerapp.backend.models.User", "classandroid_1_1app_1_1printerapp_1_1backend_1_1models_1_1_user.html", null ],
    [ "android.app.printerapp.util.ui.enums.userRoleType", "enumandroid_1_1app_1_1printerapp_1_1util_1_1ui_1_1enums_1_1user_role_type.html", null ],
    [ "it.sephiroth.android.library.util.v14.ViewHelper14", "classit_1_1sephiroth_1_1android_1_1library_1_1util_1_1v14_1_1_view_helper14.html", [
      [ "it.sephiroth.android.library.util.v16.ViewHelper16", "classit_1_1sephiroth_1_1android_1_1library_1_1util_1_1v16_1_1_view_helper16.html", null ]
    ] ],
    [ "it.sephiroth.android.library.util.ViewHelperFactory", "classit_1_1sephiroth_1_1android_1_1library_1_1util_1_1_view_helper_factory.html", null ],
    [ "android.app.printerapp.util.ui.dialogs.waitingDialog", "classandroid_1_1app_1_1printerapp_1_1util_1_1ui_1_1dialogs_1_1waiting_dialog.html", null ],
    [ "android.app.printerapp.viewer.WitboxFaces", "classandroid_1_1app_1_1printerapp_1_1viewer_1_1_witbox_faces.html", null ],
    [ "android.app.printerapp.viewer.WitboxPlate", "classandroid_1_1app_1_1printerapp_1_1viewer_1_1_witbox_plate.html", null ],
    [ "Activity", null, [
      [ "android.app.printerapp.loginScreen.loginScreenActivity", "classandroid_1_1app_1_1printerapp_1_1login_screen_1_1login_screen_activity.html", null ],
      [ "android.app.printerapp.postPrinting.StressRelieving.stressRelievingTestActivity", "classandroid_1_1app_1_1printerapp_1_1post_printing_1_1_stress_relieving_1_1stress_relieving_test_activity.html", null ]
    ] ],
    [ "AppCompatActivity", null, [
      [ "android.app.printerapp.activities.buildMainActivity", "classandroid_1_1app_1_1printerapp_1_1activities_1_1build_main_activity.html", null ],
      [ "android.app.printerapp.activities.STLViewerActivity", "classandroid_1_1app_1_1printerapp_1_1activities_1_1_s_t_l_viewer_activity.html", null ],
      [ "android.app.printerapp.homeScreen.homeScreenActivity", "classandroid_1_1app_1_1printerapp_1_1home_screen_1_1home_screen_activity.html", null ],
      [ "android.app.printerapp.magicsScreenshot.magicsScreenshotActivity", "classandroid_1_1app_1_1printerapp_1_1magics_screenshot_1_1magics_screenshot_activity.html", null ],
      [ "android.app.printerapp.postPrinting.AgingTreatment.agingTreatmentTestActivity", "classandroid_1_1app_1_1printerapp_1_1post_printing_1_1_aging_treatment_1_1aging_treatment_test_activity.html", null ],
      [ "android.app.printerapp.postPrinting.General.generalTestActivity", "classandroid_1_1app_1_1printerapp_1_1post_printing_1_1_general_1_1general_test_activity.html", null ],
      [ "android.app.printerapp.postPrinting.Hardening.hardeningTestActivity", "classandroid_1_1app_1_1printerapp_1_1post_printing_1_1_hardening_1_1hardening_test_activity.html", null ],
      [ "android.app.printerapp.postPrinting.postPrintingTestActivity", "classandroid_1_1app_1_1printerapp_1_1post_printing_1_1post_printing_test_activity.html", null ],
      [ "android.app.printerapp.postPrinting.SolutionTreatment.solutionTreatmentTestActivity", "classandroid_1_1app_1_1printerapp_1_1post_printing_1_1_solution_treatment_1_1solution_treatment_test_activity.html", null ],
      [ "android.app.printerapp.postPrinting.Tampering.tamperingTestActivity", "classandroid_1_1app_1_1printerapp_1_1post_printing_1_1_tampering_1_1tampering_test_activity.html", null ]
    ] ],
    [ "Application", null, [
      [ "android.app.printerapp.util.ui.MyApplication", "classandroid_1_1app_1_1printerapp_1_1util_1_1ui_1_1_my_application.html", null ]
    ] ],
    [ "BaseAdapter", null, [
      [ "android.app.printerapp.adapters.dialogPowderConditionAdapter", "classandroid_1_1app_1_1printerapp_1_1adapters_1_1dialog_powder_condition_adapter.html", null ],
      [ "android.app.printerapp.adapters.gridViewAdapter", "classandroid_1_1app_1_1printerapp_1_1adapters_1_1grid_view_adapter.html", null ],
      [ "android.app.printerapp.util.ui.ListIconPopupWindowAdapter", "classandroid_1_1app_1_1printerapp_1_1util_1_1ui_1_1_list_icon_popup_window_adapter.html", null ]
    ] ],
    [ "CompoundButton", null, [
      [ "com.material.widget.CheckBox", "classcom_1_1material_1_1widget_1_1_check_box.html", null ],
      [ "com.material.widget.RadioButton", "classcom_1_1material_1_1widget_1_1_radio_button.html", null ],
      [ "com.material.widget.Switch", "classcom_1_1material_1_1widget_1_1_switch.html", null ]
    ] ],
    [ "CustomView", null, [
      [ "android.app.printerapp.util.ui.CustomEditableSlider", "classandroid_1_1app_1_1printerapp_1_1util_1_1ui_1_1_custom_editable_slider.html", null ]
    ] ],
    [ "DataSetObserver", null, [
      [ "it.sephiroth.android.library.widget.ExpandableHListConnector.MyDataSetObserver", "classit_1_1sephiroth_1_1android_1_1library_1_1widget_1_1_expandable_h_list_connector_1_1_my_data_set_observer.html", null ]
    ] ],
    [ "Dialog", null, [
      [ "com.material.widget.ActionSheet", "classcom_1_1material_1_1widget_1_1_action_sheet.html", null ]
    ] ],
    [ "DialogFragment", null, [
      [ "android.app.printerapp.util.ui.dialogs.DatePickerFragment< T >", "classandroid_1_1app_1_1printerapp_1_1util_1_1ui_1_1dialogs_1_1_date_picker_fragment.html", null ],
      [ "android.app.printerapp.util.ui.dialogs.TimePickerFragment< T >", "classandroid_1_1app_1_1printerapp_1_1util_1_1ui_1_1dialogs_1_1_time_picker_fragment.html", null ]
    ] ],
    [ "Filterable", null, [
      [ "it.sephiroth.android.library.widget.HeaderViewListAdapter", "classit_1_1sephiroth_1_1android_1_1library_1_1widget_1_1_header_view_list_adapter.html", null ]
    ] ],
    [ "Fragment", null, [
      [ "android.app.printerapp.displayingData.dataFragment", "classandroid_1_1app_1_1printerapp_1_1displaying_data_1_1data_fragment.html", null ],
      [ "android.app.printerapp.homeScreen.QRScanner.QRreaderFragment", "classandroid_1_1app_1_1printerapp_1_1home_screen_1_1_q_r_scanner_1_1_q_rreader_fragment.html", null ],
      [ "android.app.printerapp.homeScreen.textScanner.textScannerFragment", "classandroid_1_1app_1_1printerapp_1_1home_screen_1_1text_scanner_1_1text_scanner_fragment.html", null ],
      [ "android.app.printerapp.viewer.ViewerMainFragment", "classandroid_1_1app_1_1printerapp_1_1viewer_1_1_viewer_main_fragment.html", null ]
    ] ],
    [ "FragmentActivity", null, [
      [ "android.app.printerapp.activities.MainActivity", "classandroid_1_1app_1_1printerapp_1_1activities_1_1_main_activity.html", null ]
    ] ],
    [ "FragmentPagerAdapter", null, [
      [ "android.app.printerapp.adapters.viewPagerAdapter", "classandroid_1_1app_1_1printerapp_1_1adapters_1_1view_pager_adapter.html", null ]
    ] ],
    [ "GLSurfaceView", null, [
      [ "android.app.printerapp.viewer.ViewerSurfaceView", "classandroid_1_1app_1_1printerapp_1_1viewer_1_1_viewer_surface_view.html", null ]
    ] ],
    [ "LinearLayout", null, [
      [ "android.app.printerapp.util.ui.customKeyboard.scannerKeyboard< T >", "classandroid_1_1app_1_1printerapp_1_1util_1_1ui_1_1custom_keyboard_1_1scanner_keyboard.html", null ]
    ] ],
    [ "SeekBar", null, [
      [ "android.app.printerapp.util.ui.VerticalSeekBar", "classandroid_1_1app_1_1printerapp_1_1util_1_1ui_1_1_vertical_seek_bar.html", null ]
    ] ],
    [ "Serializable", null, [
      [ "android.app.printerapp.displayingData.CMBuildData.buildDataController", "classandroid_1_1app_1_1printerapp_1_1displaying_data_1_1_c_m_build_data_1_1build_data_controller.html", null ],
      [ "android.app.printerapp.displayingData.CMBuildHistory.buildHistoryController", "classandroid_1_1app_1_1printerapp_1_1displaying_data_1_1_c_m_build_history_1_1build_history_controller.html", null ],
      [ "android.app.printerapp.displayingData.CMBuildStl.buildStlController", "classandroid_1_1app_1_1printerapp_1_1displaying_data_1_1_c_m_build_stl_1_1build_stl_controller.html", null ],
      [ "android.app.printerapp.postPrinting.AgingTreatment.agingTreatmentTestActivity", "classandroid_1_1app_1_1printerapp_1_1post_printing_1_1_aging_treatment_1_1aging_treatment_test_activity.html", null ],
      [ "android.app.printerapp.postPrinting.General.generalTestController", "classandroid_1_1app_1_1printerapp_1_1post_printing_1_1_general_1_1general_test_controller.html", null ],
      [ "android.app.printerapp.postPrinting.Hardening.hardeningTestActivity", "classandroid_1_1app_1_1printerapp_1_1post_printing_1_1_hardening_1_1hardening_test_activity.html", null ],
      [ "android.app.printerapp.postPrinting.postPrintingTestActivity", "classandroid_1_1app_1_1printerapp_1_1post_printing_1_1post_printing_test_activity.html", null ],
      [ "android.app.printerapp.postPrinting.RetrieveAllTests.partTestController", "classandroid_1_1app_1_1printerapp_1_1post_printing_1_1_retrieve_all_tests_1_1part_test_controller.html", null ],
      [ "android.app.printerapp.postPrinting.SolutionTreatment.solutionTreatmentTestActivity", "classandroid_1_1app_1_1printerapp_1_1post_printing_1_1_solution_treatment_1_1solution_treatment_test_activity.html", null ],
      [ "android.app.printerapp.postPrinting.StressRelieving.stressRelievingTestActivity", "classandroid_1_1app_1_1printerapp_1_1post_printing_1_1_stress_relieving_1_1stress_relieving_test_activity.html", null ],
      [ "android.app.printerapp.postPrinting.Tampering.tamperingTestActivity", "classandroid_1_1app_1_1printerapp_1_1post_printing_1_1_tampering_1_1tampering_test_activity.html", null ],
      [ "android.app.printerapp.util.ui.Personality", "classandroid_1_1app_1_1printerapp_1_1util_1_1ui_1_1_personality.html", null ]
    ] ],
    [ "View", null, [
      [ "android.app.printerapp.homeScreen.QRScanner.box", "classandroid_1_1app_1_1printerapp_1_1home_screen_1_1_q_r_scanner_1_1box.html", null ],
      [ "com.material.widget.CircleButton", "classcom_1_1material_1_1widget_1_1_circle_button.html", null ],
      [ "com.material.widget.CircularProgress", "classcom_1_1material_1_1widget_1_1_circular_progress.html", null ],
      [ "com.material.widget.LinearProgress", "classcom_1_1material_1_1widget_1_1_linear_progress.html", null ],
      [ "com.material.widget.PaperButton", "classcom_1_1material_1_1widget_1_1_paper_button.html", null ],
      [ "com.material.widget.Slider", "classcom_1_1material_1_1widget_1_1_slider.html", null ]
    ] ],
    [ "ViewGroup", null, [
      [ "it.sephiroth.android.library.widget.AdapterView< T extends Adapter >", "classit_1_1sephiroth_1_1android_1_1library_1_1widget_1_1_adapter_view.html", null ]
    ] ],
    [ "WrapperListAdapter", null, [
      [ "it.sephiroth.android.library.widget.HeaderViewListAdapter", "classit_1_1sephiroth_1_1android_1_1library_1_1widget_1_1_header_view_list_adapter.html", null ]
    ] ]
];