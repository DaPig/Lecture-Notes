var namespacecom_1_1google_1_1android_1_1gms_1_1tasks =
[
    [ "license", "namespacecom_1_1google_1_1android_1_1gms_1_1tasks_1_1license.html", "namespacecom_1_1google_1_1android_1_1gms_1_1tasks_1_1license" ],
    [ "R", "classcom_1_1google_1_1android_1_1gms_1_1tasks_1_1_r.html", null ]
];